import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import SuccessStories from "./pages/SuccessStories";
import Notifications from "./pages/Notifications";
import ShareResults from "./pages/ShareResults";
import AIFitnessCoach from "./pages/AIFitnessCoach";
import BodyComparison3D from "./pages/BodyComparison3D";
import CommunityChallenge from "./pages/CommunityChallenge";
import WorkoutVideos from "./pages/WorkoutVideos";
import WearablesSync from "./pages/WearablesSync";
import ProgressDashboard from "./pages/ProgressDashboard";

/**
 * App.tsx - O ponto de entrada principal da aplicação
 * 
 * Aqui definimos as rotas, o tema e os providers globais.
 * Mantém tudo simples e direto - sem complicações desnecessárias.
 */
// Componente Router que gerencia todas as rotas da aplicação
function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      {/* Rota principal - a página de cálculo de IMC */}
      <Route path={"/"} component={Home} />
      
      {/* Histórias de sucesso - inspiração e motivação */}
      <Route path={"/success-stories"} component={SuccessStories} />
      
      {/* Notificações personalizadas - lembretes e dicas */}
      <Route path={"/notifications"} component={Notifications} />
      
      {/* Partilha em redes sociais - celebre sua jornada */}
      <Route path={"/share"} component={ShareResults} />
      
      {/* IA Fitness Coach - assistente inteligente */}
      <Route path={"/ai-coach"} component={AIFitnessCoach} />
      
      {/* Análise Comparativa 3D - visualização interativa */}
      <Route path={"/body-comparison"} component={BodyComparison3D} />
      
      {/* Desafio Comunitário - gamificação e leaderboard */}
      <Route path={"/challenge"} component={CommunityChallenge} />
      
      {/* Biblioteca de Treinos - vídeos de exercícios */}
      <Route path={"/workouts"} component={WorkoutVideos} />
      
      {/* Sincronização com Wearables - smartwatches e fitness trackers */}
      <Route path={"/wearables"} component={WearablesSync} />
      
      {/* Dashboard de Progresso - gráficos e histórico */}
      <Route path={"/progress"} component={ProgressDashboard} />
      
      {/* Página 404 para quando algo der errado */}
      <Route path={"/404"} component={NotFound} />
      
      {/* Fallback final - se nenhuma rota bater, mostra 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

// Componente principal da aplicação
// Envolve tudo com os providers necessários (tema, tooltips, etc)
function App() {
  return (
    <ErrorBoundary>
      {/* 
        ThemeProvider com tema escuro por padrão
        Combina perfeitamente com o design cyberpunk da aplicação
      */}
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          {/* Toaster para notificações - sempre útil ter por perto */}
          <Toaster />
          
          {/* Aqui entram todas as rotas */}
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;

import { useState } from 'react';
import { Watch, Smartphone, Zap, Heart, Activity, TrendingUp, Link2, CheckCircle } from 'lucide-react';

/**
 * Wearables Sync - Sincronização com Dispositivos Wearables
 * 
 * Integração com smartwatches e fitness trackers para sincronizar dados
 * de atividade física, frequência cardíaca, passos, calorias queimadas.
 * Oferece recomendações baseadas em dados reais.
 */

interface WearableDevice {
  id: string;
  name: string;
  brand: string;
  icon: string;
  connected: boolean;
  lastSync?: string;
  dataPoints: string[];
}

interface SyncedData {
  steps: number;
  calories: number;
  heartRate: number;
  distance: number;
  activeMinutes: number;
  sleep: number;
}

const wearableDevices: WearableDevice[] = [
  {
    id: 'apple-watch',
    name: 'Apple Watch',
    brand: 'Apple',
    icon: '⌚',
    connected: true,
    lastSync: 'Há 2 minutos',
    dataPoints: ['Passos', 'Calorias', 'Frequência Cardíaca', 'Treino', 'Sono']
  },
  {
    id: 'fitbit',
    name: 'Fitbit Charge 5',
    brand: 'Fitbit',
    icon: '📱',
    connected: false,
    dataPoints: ['Passos', 'Calorias', 'Frequência Cardíaca', 'Sono', 'Estresse']
  },
  {
    id: 'garmin',
    name: 'Garmin Fenix',
    brand: 'Garmin',
    icon: '🎯',
    connected: true,
    lastSync: 'Há 5 minutos',
    dataPoints: ['Passos', 'Calorias', 'GPS', 'Treino', 'Recuperação']
  },
  {
    id: 'samsung',
    name: 'Samsung Galaxy Watch',
    brand: 'Samsung',
    icon: '⌚',
    connected: false,
    dataPoints: ['Passos', 'Calorias', 'Frequência Cardíaca', 'Treino', 'Sono']
  },
  {
    id: 'xiaomi',
    name: 'Xiaomi Mi Band',
    brand: 'Xiaomi',
    icon: '📱',
    connected: false,
    dataPoints: ['Passos', 'Calorias', 'Frequência Cardíaca', 'Sono']
  },
  {
    id: 'whoop',
    name: 'WHOOP Band',
    brand: 'WHOOP',
    icon: '💪',
    connected: false,
    dataPoints: ['Frequência Cardíaca', 'Recuperação', 'Treino', 'Sono']
  },
];

export default function WearablesSync() {
  const [connectedDevices, setConnectedDevices] = useState<string[]>(['apple-watch', 'garmin']);
  const [syncedData] = useState<SyncedData>({
    steps: 8234,
    calories: 520,
    heartRate: 72,
    distance: 6.2,
    activeMinutes: 45,
    sleep: 7.5
  });

  const toggleConnection = (deviceId: string) => {
    setConnectedDevices(prev =>
      prev.includes(deviceId)
        ? prev.filter(id => id !== deviceId)
        : [...prev, deviceId]
    );
  };

  const getConnectedDevice = () => {
    return wearableDevices.find(d => connectedDevices.includes(d.id));
  };

  const connectedDevice = getConnectedDevice();

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Fundo com gradiente */}
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-[#0a0e27] via-[#1a1f3a] to-[#0f1a35]" />
        <div className="absolute top-0 left-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-magenta-500/5 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }} />
      </div>

      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4 py-8">
        {/* Cabeçalho */}
        <div className="text-center mb-8 animate-fade-in">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Watch className="w-8 h-8 text-cyan-400" />
            <h1 className="text-4xl md:text-5xl font-black neon-text">
              SINCRONIZAÇÃO WEARABLES
            </h1>
            <Smartphone className="w-8 h-8 text-magenta-400" />
          </div>
          <p className="text-gray-300">Conecte seus dispositivos e sincronize dados de fitness em tempo real</p>
        </div>

        <div className="w-full max-w-6xl space-y-8">
          {/* Dados Sincronizados */}
          {connectedDevice && (
            <div className="glass-effect p-8 rounded-2xl animate-fade-in">
              <h2 className="text-2xl font-bold neon-text mb-6">
                📊 Dados de Hoje - {connectedDevice.name}
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {/* Passos */}
                <div className="bg-gradient-to-br from-cyan-500/10 to-cyan-500/5 border border-cyan-500/30 p-6 rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <Activity className="w-6 h-6 text-cyan-400" />
                    <span className="text-cyan-400 font-bold">Passos</span>
                  </div>
                  <div className="text-3xl font-black text-cyan-400 mb-2">{syncedData.steps.toLocaleString()}</div>
                  <div className="w-full bg-gray-700 rounded-full h-2">
                    <div className="bg-cyan-500 h-2 rounded-full" style={{ width: '82%' }} />
                  </div>
                  <p className="text-xs text-gray-400 mt-2">Meta: 10.000 passos</p>
                </div>

                {/* Calorias */}
                <div className="bg-gradient-to-br from-magenta-500/10 to-magenta-500/5 border border-magenta-500/30 p-6 rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <Zap className="w-6 h-6 text-magenta-400" />
                    <span className="text-magenta-400 font-bold">Calorias</span>
                  </div>
                  <div className="text-3xl font-black text-magenta-400 mb-2">{syncedData.calories}</div>
                  <div className="w-full bg-gray-700 rounded-full h-2">
                    <div className="bg-magenta-500 h-2 rounded-full" style={{ width: '52%' }} />
                  </div>
                  <p className="text-xs text-gray-400 mt-2">Meta: 1.000 calorias</p>
                </div>

                {/* Frequência Cardíaca */}
                <div className="bg-gradient-to-br from-red-500/10 to-red-500/5 border border-red-500/30 p-6 rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <Heart className="w-6 h-6 text-red-400" />
                    <span className="text-red-400 font-bold">Freq. Cardíaca</span>
                  </div>
                  <div className="text-3xl font-black text-red-400 mb-2">{syncedData.heartRate} BPM</div>
                  <p className="text-xs text-gray-400">Normal: 60-100 BPM</p>
                </div>

                {/* Distância */}
                <div className="bg-gradient-to-br from-green-500/10 to-green-500/5 border border-green-500/30 p-6 rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <TrendingUp className="w-6 h-6 text-green-400" />
                    <span className="text-green-400 font-bold">Distância</span>
                  </div>
                  <div className="text-3xl font-black text-green-400 mb-2">{syncedData.distance} km</div>
                  <p className="text-xs text-gray-400">Equivalente a 8.234 passos</p>
                </div>

                {/* Minutos Ativos */}
                <div className="bg-gradient-to-br from-yellow-500/10 to-yellow-500/5 border border-yellow-500/30 p-6 rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <Activity className="w-6 h-6 text-yellow-400" />
                    <span className="text-yellow-400 font-bold">Minutos Ativos</span>
                  </div>
                  <div className="text-3xl font-black text-yellow-400 mb-2">{syncedData.activeMinutes}</div>
                  <p className="text-xs text-gray-400">Meta: 60 minutos/dia</p>
                </div>

                {/* Sono */}
                <div className="bg-gradient-to-br from-purple-500/10 to-purple-500/5 border border-purple-500/30 p-6 rounded-lg">
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-purple-400 font-bold">😴 Sono</span>
                  </div>
                  <div className="text-3xl font-black text-purple-400 mb-2">{syncedData.sleep}h</div>
                  <p className="text-xs text-gray-400">Meta: 7-9 horas/noite</p>
                </div>
              </div>

              {/* Recomendações */}
              <div className="mt-6 p-4 bg-cyan-500/10 border border-cyan-500/30 rounded-lg">
                <p className="text-cyan-400 font-semibold mb-2">💡 Recomendação Inteligente:</p>
                <p className="text-gray-300 text-sm">
                  Você está no caminho certo! Você queimou {syncedData.calories} calorias e caminhou {syncedData.distance}km. 
                  Continue assim e você alcançará seus objetivos. Não esqueça de beber água e descansar bem!
                </p>
              </div>
            </div>
          )}

          {/* Dispositivos Disponíveis */}
          <div className="glass-effect p-8 rounded-2xl">
            <h2 className="text-2xl font-bold neon-text mb-6">
              ⌚ Dispositivos Disponíveis
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {wearableDevices.map((device, idx) => (
                <div
                  key={device.id}
                  className={`p-6 rounded-lg border-2 transition-all animate-slide-in-up ${
                    connectedDevices.includes(device.id)
                      ? 'border-cyan-500 bg-cyan-500/10'
                      : 'border-gray-700 bg-gray-800/30 hover:border-gray-600'
                  }`}
                  style={{ animationDelay: `${idx * 0.1}s` }}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <div className="text-4xl mb-2">{device.icon}</div>
                      <h3 className="font-bold text-cyan-400">{device.name}</h3>
                      <p className="text-xs text-gray-400">{device.brand}</p>
                    </div>
                    {connectedDevices.includes(device.id) && (
                      <CheckCircle className="w-6 h-6 text-green-400" />
                    )}
                  </div>

                  {/* Pontos de Dados */}
                  <div className="mb-4">
                    <p className="text-xs text-gray-400 mb-2">Dados sincronizáveis:</p>
                    <div className="flex flex-wrap gap-1">
                      {device.dataPoints.map((point) => (
                        <span key={point} className="px-2 py-1 bg-gray-700 text-gray-300 text-xs rounded">
                          {point}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Status */}
                  {connectedDevices.includes(device.id) && device.lastSync && (
                    <p className="text-xs text-green-400 mb-3">✓ Sincronizado {device.lastSync}</p>
                  )}

                  {/* Botão */}
                  <button
                    onClick={() => toggleConnection(device.id)}
                    className={`w-full px-4 py-2 rounded-lg font-semibold text-sm transition-all ${
                      connectedDevices.includes(device.id)
                        ? 'bg-red-500/20 border border-red-500 text-red-400 hover:bg-red-500/30'
                        : 'bg-cyan-500/20 border border-cyan-500 text-cyan-400 hover:bg-cyan-500/30'
                    }`}
                  >
                    <Link2 className="w-4 h-4 inline mr-2" />
                    {connectedDevices.includes(device.id) ? 'Desconectar' : 'Conectar'}
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Benefícios */}
          <div className="glass-effect p-8 rounded-2xl">
            <h2 className="text-2xl font-bold neon-text mb-6">🎯 Benefícios da Sincronização</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-cyan-500/10 border border-cyan-500/30 rounded-lg">
                <p className="font-bold text-cyan-400 mb-2">📈 Acompanhamento Automático</p>
                <p className="text-sm text-gray-300">Seus dados de fitness são sincronizados automaticamente em tempo real.</p>
              </div>
              <div className="p-4 bg-magenta-500/10 border border-magenta-500/30 rounded-lg">
                <p className="font-bold text-magenta-400 mb-2">🎯 Recomendações Personalizadas</p>
                <p className="text-sm text-gray-300">Receba dicas baseadas em seus dados reais de atividade.</p>
              </div>
              <div className="p-4 bg-green-500/10 border border-green-500/30 rounded-lg">
                <p className="font-bold text-green-400 mb-2">📊 Análise Detalhada</p>
                <p className="text-sm text-gray-300">Visualize tendências e padrões em seu progresso de fitness.</p>
              </div>
              <div className="p-4 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
                <p className="font-bold text-yellow-400 mb-2">🏆 Metas Inteligentes</p>
                <p className="text-sm text-gray-300">Defina e acompanhe metas baseadas em seus dados históricos.</p>
              </div>
            </div>
          </div>
        </div>

        {/* Botão voltar */}
        <div className="mt-12">
          <a
            href="/"
            className="inline-block px-6 py-3 bg-gradient-to-r from-cyan-500 to-magenta-500 text-white font-bold rounded-lg hover:shadow-lg hover:shadow-cyan-500/50 transition-all"
          >
            ← Voltar ao Calculador
          </a>
        </div>
      </div>
    </div>
  );
}

import { useState } from 'react';
import { Share2, Heart, Copy, CheckCircle, X } from 'lucide-react';

/**
 * Share Results - Partilha em Redes Sociais
 * 
 * Aqui os utilizadores podem partilhar seus resultados de IMC
 * e recomendações nas redes sociais para celebrar sua jornada
 * e inspirar outras pessoas.
 */

interface ShareOption {
  id: string;
  name: string;
  icon: string;
  color: string;
  url: string;
  description: string;
}

export default function ShareResults() {
  const [showCopyNotification, setShowCopyNotification] = useState(false);
  const [selectedIMC] = useState({
    value: 24.5,
    category: 'Peso Normal',
    name: 'João Silva'
  });

  // Opções de partilha
  const shareOptions: ShareOption[] = [
    {
      id: 'whatsapp',
      name: 'WhatsApp',
      icon: '💬',
      color: 'from-green-400 to-green-600',
      url: 'https://wa.me/?text=',
      description: 'Partilhe com amigos e família'
    },
    {
      id: 'instagram',
      name: 'Instagram',
      icon: '📸',
      color: 'from-pink-400 to-purple-600',
      url: 'https://instagram.com',
      description: 'Partilhe sua transformação'
    },
    {
      id: 'facebook',
      name: 'Facebook',
      icon: '👍',
      color: 'from-blue-400 to-blue-600',
      url: 'https://facebook.com/sharer/sharer.php?u=',
      description: 'Partilhe com sua rede'
    },
    {
      id: 'twitter',
      name: 'Twitter',
      icon: '𝕏',
      color: 'from-gray-400 to-gray-600',
      url: 'https://twitter.com/intent/tweet?text=',
      description: 'Partilhe seu progresso'
    },
    {
      id: 'linkedin',
      name: 'LinkedIn',
      icon: '💼',
      color: 'from-blue-500 to-blue-700',
      url: 'https://www.linkedin.com/sharing/share-offsite/?url=',
      description: 'Partilhe profissionalmente'
    },
    {
      id: 'email',
      name: 'Email',
      icon: '✉️',
      color: 'from-orange-400 to-orange-600',
      url: 'mailto:?subject=',
      description: 'Envie por email'
    }
  ];

  // Mensagem personalizada
  const generateShareMessage = () => {
    return `Acabei de calcular meu IMC com o Maria Sambé IMC! 🎉\n\nMeu Resultado:\n📊 IMC: ${selectedIMC.value}\n✅ Categoria: ${selectedIMC.category}\n\nCom as recomendações personalizadas do Maria Sambé IMC, estou no caminho certo para minha saúde e bem-estar! 💪\n\nVocê também pode calcular seu IMC: https://maria-sambe-imc.com`;
  };

  // Função para copiar link
  const handleCopyLink = () => {
    const link = 'https://maria-sambe-imc.com';
    navigator.clipboard.writeText(link);
    setShowCopyNotification(true);
    setTimeout(() => setShowCopyNotification(false), 2000);
  };

  // Função para partilhar
  const handleShare = (option: ShareOption) => {
    const message = generateShareMessage();
    const encodedMessage = encodeURIComponent(message);
    
    let shareUrl = '';
    
    switch (option.id) {
      case 'whatsapp':
        shareUrl = `https://wa.me/?text=${encodedMessage}`;
        break;
      case 'twitter':
        shareUrl = `https://twitter.com/intent/tweet?text=${encodedMessage}`;
        break;
      case 'facebook':
        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=https://maria-sambe-imc.com`;
        break;
      case 'linkedin':
        shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=https://maria-sambe-imc.com`;
        break;
      case 'email':
        shareUrl = `mailto:?subject=Confira meu resultado de IMC&body=${encodedMessage}`;
        break;
      case 'instagram':
        // Instagram não tem API de compartilhamento direta, então copiamos o texto
        navigator.clipboard.writeText(message);
        setShowCopyNotification(true);
        setTimeout(() => setShowCopyNotification(false), 2000);
        return;
      default:
        return;
    }
    
    if (shareUrl) {
      window.open(shareUrl, '_blank');
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Fundo com gradiente */}
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-[#0a0e27] via-[#1a1f3a] to-[#0f1a35]" />
        <div className="absolute top-0 left-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-magenta-500/5 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }} />
      </div>

      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4 py-8">
        {/* Cabeçalho */}
        <div className="text-center mb-12 animate-fade-in">
          <Share2 className="w-16 h-16 mx-auto text-cyan-400 mb-4" />
          <h1 className="text-5xl md:text-6xl font-black mb-4 neon-text">
            PARTILHE SEU RESULTADO
          </h1>
          <p className="text-lg md:text-xl text-gray-300 font-light">
            Celebre sua jornada de saúde e inspire outras pessoas
          </p>
          <div className="h-1 w-24 mx-auto mt-4 bg-gradient-to-r from-cyan-500 via-magenta-500 to-green-400 rounded-full" />
        </div>

        <div className="w-full max-w-4xl space-y-8">
          {/* Card com resultado */}
          <div className="glass-effect p-8 rounded-2xl animate-slide-in-up">
            <h2 className="text-2xl font-bold neon-text-magenta mb-6">
              Seu Resultado
            </h2>

            <div className="grid grid-cols-3 gap-4 mb-6">
              <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-6 text-center">
                <div className="text-xs text-gray-400 mb-2">IMC</div>
                <div className="text-4xl font-black text-cyan-400">{selectedIMC.value}</div>
              </div>
              <div className="bg-magenta-500/10 border border-magenta-500/30 rounded-lg p-6 text-center flex flex-col justify-center">
                <Heart className="w-8 h-8 mx-auto text-magenta-400 mb-2" />
                <div className="text-sm text-gray-400">Status</div>
              </div>
              <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-6 text-center">
                <div className="text-xs text-gray-400 mb-2">Categoria</div>
                <div className="text-lg font-bold text-green-400">{selectedIMC.category}</div>
              </div>
            </div>

            {/* Mensagem de partilha */}
            <div className="bg-gray-800/50 rounded-lg p-6 border-l-4 border-cyan-500 mb-6">
              <p className="text-gray-300 text-sm whitespace-pre-wrap">
                {generateShareMessage()}
              </p>
            </div>

            {/* Botão copiar link */}
            <button
              onClick={handleCopyLink}
              className="w-full px-6 py-3 bg-gray-700 hover:bg-gray-600 border border-cyan-500/30 text-cyan-400 font-bold rounded-lg transition-all flex items-center justify-center gap-2"
            >
              <Copy className="w-5 h-5" />
              Copiar Link
            </button>
          </div>

          {/* Opções de partilha */}
          <div className="glass-effect p-8 rounded-2xl">
            <h2 className="text-2xl font-bold neon-text-magenta mb-6">
              Partilhe em Redes Sociais
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {shareOptions.map((option, idx) => (
                <button
                  key={option.id}
                  onClick={() => handleShare(option)}
                  className={`p-6 rounded-lg border border-gray-700 hover:border-cyan-500 transition-all animate-slide-in-up bg-gradient-to-br ${option.color} opacity-10 hover:opacity-20`}
                  style={{ animationDelay: `${idx * 0.1}s` }}
                >
                  <div className="space-y-3">
                    <div className="text-4xl">{option.icon}</div>
                    <div>
                      <h3 className="text-lg font-bold text-gray-300">{option.name}</h3>
                      <p className="text-xs text-gray-400 mt-1">{option.description}</p>
                    </div>
                    <div className="pt-2 text-sm text-cyan-400 font-semibold">
                      Partilhar →
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Dicas de partilha */}
          <div className="glass-effect p-8 rounded-2xl">
            <h2 className="text-2xl font-bold neon-text-magenta mb-6">
              Dicas para Partilhar
            </h2>

            <div className="space-y-4">
              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-8 w-8 rounded-lg bg-cyan-500/20 text-cyan-400 font-bold">
                    1
                  </div>
                </div>
                <div>
                  <h3 className="text-lg font-bold text-cyan-400 mb-1">Celebre sua jornada</h3>
                  <p className="text-gray-400">Partilhe seus resultados e inspire outras pessoas a começarem sua transformação de saúde.</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-8 w-8 rounded-lg bg-magenta-500/20 text-magenta-400 font-bold">
                    2
                  </div>
                </div>
                <div>
                  <h3 className="text-lg font-bold text-magenta-400 mb-1">Use hashtags relevantes</h3>
                  <p className="text-gray-400">#SaúdeEmPrimeiro #TransformaçãoFísica #BemEstar #FitnessJourney #MariaSambéIMC</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="flex items-center justify-center h-8 w-8 rounded-lg bg-green-500/20 text-green-400 font-bold">
                    3
                  </div>
                </div>
                <div>
                  <h3 className="text-lg font-bold text-green-400 mb-1">Convide seus amigos</h3>
                  <p className="text-gray-400">Partilhe o link do Maria Sambé IMC para que seus amigos também possam calcular seu IMC e receber recomendações personalizadas.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Notificação de sucesso */}
          {showCopyNotification && (
            <div className="fixed bottom-8 right-8 bg-green-500/20 border border-green-500 rounded-lg p-4 animate-fade-in flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-400" />
              <span className="font-semibold text-green-400">Copiado para a área de transferência!</span>
              <button
                onClick={() => setShowCopyNotification(false)}
                className="ml-2 text-green-400 hover:text-green-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>

        {/* Chamada para ação */}
        <div className="mt-16 text-center max-w-2xl animate-fade-in">
          <div className="glass-effect p-8 rounded-2xl">
            <h2 className="text-2xl font-bold neon-text mb-4">
              Ainda não calculou seu IMC?
            </h2>
            <p className="text-gray-300 mb-6">
              Comece agora e receba recomendações personalizadas para sua saúde e bem-estar.
            </p>
            <a
              href="/"
              className="inline-block px-8 py-3 bg-gradient-to-r from-cyan-500 to-magenta-500 text-white font-bold rounded-lg hover:shadow-lg hover:shadow-cyan-500/50 transition-all"
            >
              Calcular IMC
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useState } from 'react';
import { TrendingUp, Calendar, Target, Award, BarChart3, LineChart } from 'lucide-react';

/**
 * Progress Dashboard - Dashboard de Progresso com Gráficos
 * 
 * Visualização completa da evolução do IMC ao longo do tempo,
 * histórico de medições, metas personalizadas, e estatísticas detalhadas.
 * Gráficos interativos para acompanhar progresso.
 */

interface IMCRecord {
  date: string;
  imc: number;
  weight: number;
  category: string;
}

interface Goal {
  id: string;
  targetIMC: number;
  targetDate: string;
  currentProgress: number;
  status: 'active' | 'completed' | 'abandoned';
}

const imcHistory: IMCRecord[] = [
  { date: '2025-11-01', imc: 28.5, weight: 95, category: 'Pré-Obesidade' },
  { date: '2025-11-08', imc: 28.2, weight: 94, category: 'Pré-Obesidade' },
  { date: '2025-11-15', imc: 27.8, weight: 93, category: 'Pré-Obesidade' },
  { date: '2025-11-22', imc: 27.4, weight: 92, category: 'Pré-Obesidade' },
  { date: '2025-11-29', imc: 26.9, weight: 90, category: 'Pré-Obesidade' },
  { date: '2025-12-06', imc: 26.5, weight: 89, category: 'Pré-Obesidade' },
];

const goals: Goal[] = [
  {
    id: '1',
    targetIMC: 24.9,
    targetDate: '2026-03-06',
    currentProgress: 65,
    status: 'active'
  },
  {
    id: '2',
    targetIMC: 22,
    targetDate: '2026-06-06',
    currentProgress: 40,
    status: 'active'
  },
];

export default function ProgressDashboard() {
  const [timeRange, setTimeRange] = useState<'week' | 'month' | 'all'>('month');
  const [selectedMetric, setSelectedMetric] = useState<'imc' | 'weight'>('imc');

  const currentRecord = imcHistory[imcHistory.length - 1];
  const firstRecord = imcHistory[0];
  const imcChange = (firstRecord.imc - currentRecord.imc).toFixed(1);
  const weightChange = (firstRecord.weight - currentRecord.weight).toFixed(1);

  // Simular dados de gráfico
  const getChartData = () => {
    return imcHistory.map((record, idx) => ({
      x: idx,
      y: selectedMetric === 'imc' ? record.imc : record.weight,
      label: record.date.split('-')[2]
    }));
  };

  const chartData = getChartData();

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Fundo com gradiente */}
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-[#0a0e27] via-[#1a1f3a] to-[#0f1a35]" />
        <div className="absolute top-0 left-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-magenta-500/5 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }} />
      </div>

      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4 py-8">
        {/* Cabeçalho */}
        <div className="text-center mb-8 animate-fade-in">
          <div className="flex items-center justify-center gap-3 mb-4">
            <BarChart3 className="w-8 h-8 text-cyan-400" />
            <h1 className="text-4xl md:text-5xl font-black neon-text">
              DASHBOARD DE PROGRESSO
            </h1>
            <TrendingUp className="w-8 h-8 text-magenta-400" />
          </div>
          <p className="text-gray-300">Acompanhe sua evolução de saúde em tempo real</p>
        </div>

        <div className="w-full max-w-6xl space-y-8">
          {/* Estatísticas Principais */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="glass-effect p-6 rounded-lg text-center animate-slide-in-up">
              <div className="text-3xl mb-2">📊</div>
              <p className="text-gray-400 text-sm mb-2">IMC Atual</p>
              <p className="text-3xl font-black text-cyan-400">{currentRecord.imc}</p>
              <p className="text-xs text-green-400 mt-1">↓ {imcChange} desde início</p>
            </div>

            <div className="glass-effect p-6 rounded-lg text-center animate-slide-in-up" style={{ animationDelay: '0.1s' }}>
              <div className="text-3xl mb-2">⚖️</div>
              <p className="text-gray-400 text-sm mb-2">Peso Atual</p>
              <p className="text-3xl font-black text-magenta-400">{currentRecord.weight}kg</p>
              <p className="text-xs text-green-400 mt-1">↓ {weightChange}kg perdidos</p>
            </div>

            <div className="glass-effect p-6 rounded-lg text-center animate-slide-in-up" style={{ animationDelay: '0.2s' }}>
              <div className="text-3xl mb-2">📈</div>
              <p className="text-gray-400 text-sm mb-2">Categoria</p>
              <p className="text-2xl font-bold text-yellow-400">{currentRecord.category}</p>
              <p className="text-xs text-gray-400 mt-1">Progredindo bem!</p>
            </div>

            <div className="glass-effect p-6 rounded-lg text-center animate-slide-in-up" style={{ animationDelay: '0.3s' }}>
              <div className="text-3xl mb-2">📅</div>
              <p className="text-gray-400 text-sm mb-2">Medições</p>
              <p className="text-3xl font-black text-green-400">{imcHistory.length}</p>
              <p className="text-xs text-gray-400 mt-1">Últimas 5 semanas</p>
            </div>
          </div>

          {/* Gráfico de Progresso */}
          <div className="glass-effect p-8 rounded-2xl">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold neon-text flex items-center gap-2">
                <LineChart className="w-6 h-6" />
                Gráfico de Evolução
              </h2>
              <div className="flex gap-2">
                {(['week', 'month', 'all'] as const).map((range) => (
                  <button
                    key={range}
                    onClick={() => setTimeRange(range)}
                    className={`px-3 py-1 rounded text-sm font-semibold transition-all ${
                      timeRange === range
                        ? 'bg-cyan-500 text-white'
                        : 'bg-gray-800 text-gray-400 hover:text-gray-300'
                    }`}
                  >
                    {range === 'week' ? 'Semana' : range === 'month' ? 'Mês' : 'Tudo'}
                  </button>
                ))}
              </div>
            </div>

            {/* Seletor de Métrica */}
            <div className="flex gap-2 mb-6">
              {(['imc', 'weight'] as const).map((metric) => (
                <button
                  key={metric}
                  onClick={() => setSelectedMetric(metric)}
                  className={`px-4 py-2 rounded-lg font-semibold transition-all ${
                    selectedMetric === metric
                      ? 'bg-gradient-to-r from-cyan-500 to-magenta-500 text-white'
                      : 'bg-gray-800 text-gray-400 hover:text-gray-300'
                  }`}
                >
                  {metric === 'imc' ? '📊 IMC' : '⚖️ Peso'}
                </button>
              ))}
            </div>

            {/* Gráfico Simulado */}
            <div className="bg-gray-800/50 p-6 rounded-lg mb-4">
              <div className="flex items-end justify-between h-64 gap-2">
                {chartData.map((point, idx) => (
                  <div
                    key={idx}
                    className="flex-1 flex flex-col items-center"
                  >
                    <div
                      className="w-full bg-gradient-to-t from-cyan-500 to-magenta-500 rounded-t transition-all hover:opacity-80"
                      style={{
                        height: `${(point.y / Math.max(...chartData.map(p => p.y))) * 100}%`,
                        minHeight: '4px'
                      }}
                    />
                    <p className="text-xs text-gray-400 mt-2">{point.label}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Legenda */}
            <div className="text-sm text-gray-400">
              <p>Eixo Y: {selectedMetric === 'imc' ? 'IMC' : 'Peso (kg)'} | Eixo X: Data</p>
            </div>
          </div>

          {/* Metas */}
          <div className="glass-effect p-8 rounded-2xl">
            <h2 className="text-2xl font-bold neon-text mb-6 flex items-center gap-2">
              <Target className="w-6 h-6" />
              Suas Metas
            </h2>

            <div className="space-y-4">
              {goals.map((goal, idx) => (
                <div
                  key={goal.id}
                  className="p-6 border-2 border-cyan-500/30 bg-cyan-500/10 rounded-lg animate-slide-in-up"
                  style={{ animationDelay: `${idx * 0.1}s` }}
                >
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="font-bold text-cyan-400 mb-1">
                        Meta {idx + 1}: IMC {goal.targetIMC}
                      </h3>
                      <p className="text-sm text-gray-400">
                        Até {new Date(goal.targetDate).toLocaleDateString('pt-PT')}
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-black text-cyan-400">{goal.currentProgress}%</div>
                      <p className="text-xs text-gray-400">Progresso</p>
                    </div>
                  </div>

                  {/* Barra de Progresso */}
                  <div className="w-full bg-gray-700 rounded-full h-3">
                    <div
                      className="bg-gradient-to-r from-cyan-500 to-magenta-500 h-3 rounded-full transition-all"
                      style={{ width: `${goal.currentProgress}%` }}
                    />
                  </div>

                  {/* Detalhes */}
                  <div className="mt-4 grid grid-cols-2 gap-4">
                    <div className="p-3 bg-gray-800/50 rounded">
                      <p className="text-xs text-gray-400 mb-1">IMC Atual</p>
                      <p className="font-bold text-cyan-400">{currentRecord.imc}</p>
                    </div>
                    <div className="p-3 bg-gray-800/50 rounded">
                      <p className="text-xs text-gray-400 mb-1">Falta</p>
                      <p className="font-bold text-magenta-400">{(goal.targetIMC - currentRecord.imc).toFixed(1)}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Histórico Completo */}
          <div className="glass-effect p-8 rounded-2xl">
            <h2 className="text-2xl font-bold neon-text mb-6 flex items-center gap-2">
              <Calendar className="w-6 h-6" />
              Histórico de Medições
            </h2>

            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-gray-700">
                    <th className="text-left py-3 px-4 text-cyan-400">Data</th>
                    <th className="text-left py-3 px-4 text-cyan-400">IMC</th>
                    <th className="text-left py-3 px-4 text-cyan-400">Peso (kg)</th>
                    <th className="text-left py-3 px-4 text-cyan-400">Categoria</th>
                    <th className="text-left py-3 px-4 text-cyan-400">Mudança</th>
                  </tr>
                </thead>
                <tbody>
                  {imcHistory.map((record, idx) => {
                    const prevRecord = idx > 0 ? imcHistory[idx - 1] : null;
                    const imcDiff = prevRecord ? (record.imc - prevRecord.imc).toFixed(1) : '—';
                    const isImprovement = prevRecord && record.imc < prevRecord.imc;

                    return (
                      <tr key={idx} className="border-b border-gray-800 hover:bg-gray-800/30 transition-all">
                        <td className="py-3 px-4 text-gray-300">{new Date(record.date).toLocaleDateString('pt-PT')}</td>
                        <td className="py-3 px-4 font-bold text-cyan-400">{record.imc}</td>
                        <td className="py-3 px-4 text-gray-300">{record.weight}</td>
                        <td className="py-3 px-4 text-gray-300">{record.category}</td>
                        <td className={`py-3 px-4 font-bold ${isImprovement ? 'text-green-400' : 'text-gray-400'}`}>
                          {isImprovement ? '↓' : '→'} {imcDiff}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Insights */}
          <div className="glass-effect p-8 rounded-2xl">
            <h2 className="text-2xl font-bold neon-text mb-6 flex items-center gap-2">
              <Award className="w-6 h-6" />
              Insights e Recomendações
            </h2>

            <div className="space-y-4">
              <div className="p-4 bg-green-500/10 border border-green-500/30 rounded-lg">
                <p className="font-bold text-green-400 mb-2">✅ Progresso Consistente</p>
                <p className="text-sm text-gray-300">
                  Você está reduzindo seu IMC consistentemente. Perdeu {imcChange} pontos de IMC em 5 semanas!
                </p>
              </div>

              <div className="p-4 bg-cyan-500/10 border border-cyan-500/30 rounded-lg">
                <p className="font-bold text-cyan-400 mb-2">🎯 Meta Próxima</p>
                <p className="text-sm text-gray-300">
                  Você está 65% do caminho para sua primeira meta. Continue assim e alcançará em breve!
                </p>
              </div>

              <div className="p-4 bg-magenta-500/10 border border-magenta-500/30 rounded-lg">
                <p className="font-bold text-magenta-400 mb-2">💡 Dica</p>
                <p className="text-sm text-gray-300">
                  Mantenha a consistência! Medições regulares ajudam a manter a motivação e rastrear progresso real.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Botão voltar */}
        <div className="mt-12">
          <a
            href="/"
            className="inline-block px-6 py-3 bg-gradient-to-r from-cyan-500 to-magenta-500 text-white font-bold rounded-lg hover:shadow-lg hover:shadow-cyan-500/50 transition-all"
          >
            ← Voltar ao Calculador
          </a>
        </div>
      </div>
    </div>
  );
}

import { useState } from 'react';
import { ChevronLeft, ChevronRight, RotateCw, ZoomIn, ZoomOut } from 'lucide-react';

/**
 * Body Comparison 3D - Análise Visual Comparativa
 * 
 * Visualização interativa que mostra o corpo em diferentes categorias de IMC.
 * Permite ao utilizador ver diferenças visuais entre categorias e entender
 * melhor o impacto do IMC no corpo.
 */

interface BodyCategory {
  id: string;
  name: string;
  imc: string;
  color: string;
  emoji: string;
  description: string;
  bodyShape: string;
}

const bodyCategories: BodyCategory[] = [
  {
    id: 'underweight',
    name: 'Abaixo do Peso',
    imc: '< 18.5',
    color: 'from-cyan-400 to-cyan-600',
    emoji: '🏃',
    description: 'Corpo magro, precisa ganhar massa muscular',
    bodyShape: '▁▂▂▂▁'
  },
  {
    id: 'normal',
    name: 'Peso Normal',
    imc: '18.5 - 24.9',
    color: 'from-green-400 to-green-600',
    emoji: '💪',
    description: 'Corpo saudável e equilibrado',
    bodyShape: '▂▄▄▄▂'
  },
  {
    id: 'overweight',
    name: 'Pré-Obesidade',
    imc: '25 - 29.9',
    color: 'from-yellow-400 to-yellow-600',
    emoji: '⚠️',
    description: 'Corpo com excesso de peso, recomenda-se exercício',
    bodyShape: '▃▅▅▅▃'
  },
  {
    id: 'obese1',
    name: 'Obesidade I',
    imc: '30 - 34.9',
    color: 'from-orange-400 to-orange-600',
    emoji: '⚠️⚠️',
    description: 'Corpo com obesidade, intervenção recomendada',
    bodyShape: '▄▆▆▆▄'
  },
  {
    id: 'obese2',
    name: 'Obesidade II',
    imc: '35 - 39.9',
    color: 'from-red-400 to-red-600',
    emoji: '🆘',
    description: 'Corpo com obesidade severa, ação urgente recomendada',
    bodyShape: '▅▇▇▇▅'
  }
];

export default function BodyComparison3D() {
  const [selectedIndex, setSelectedIndex] = useState(1); // Começa no "Peso Normal"
  const [rotation, setRotation] = useState(0);
  const [zoom, setZoom] = useState(100);

  const currentCategory = bodyCategories[selectedIndex];

  const handlePrevious = () => {
    setSelectedIndex(prev => (prev > 0 ? prev - 1 : bodyCategories.length - 1));
  };

  const handleNext = () => {
    setSelectedIndex(prev => (prev < bodyCategories.length - 1 ? prev + 1 : 0));
  };

  const handleRotate = () => {
    setRotation(prev => (prev + 45) % 360);
  };

  const handleZoomIn = () => {
    setZoom(prev => Math.min(prev + 10, 150));
  };

  const handleZoomOut = () => {
    setZoom(prev => Math.max(prev - 10, 50));
  };

  const handleReset = () => {
    setRotation(0);
    setZoom(100);
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Fundo com gradiente */}
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-[#0a0e27] via-[#1a1f3a] to-[#0f1a35]" />
        <div className="absolute top-0 left-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-magenta-500/5 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }} />
      </div>

      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4 py-8">
        {/* Cabeçalho */}
        <div className="text-center mb-8 animate-fade-in">
          <h1 className="text-4xl md:text-5xl font-black neon-text mb-2">
            ANÁLISE COMPARATIVA 3D
          </h1>
          <p className="text-gray-300">Visualize as diferenças entre categorias de IMC</p>
        </div>

        <div className="w-full max-w-4xl space-y-8">
          {/* Visualização 3D */}
          <div className="glass-effect p-8 rounded-2xl">
            {/* Corpo 3D Simulado */}
            <div className="flex flex-col items-center justify-center mb-8">
              <div
                className="relative w-32 h-64 md:w-48 md:h-96 flex items-center justify-center mb-6 transition-transform duration-300"
                style={{
                  transform: `rotateY(${rotation}deg) scale(${zoom / 100})`,
                  perspective: '1000px'
                }}
              >
                {/* Corpo visual */}
                <div className={`text-center text-8xl md:text-9xl animate-float`}>
                  {currentCategory.emoji}
                </div>

                {/* Silhueta do corpo */}
                <div className={`absolute inset-0 flex items-center justify-center`}>
                  <div className={`text-6xl md:text-8xl font-black text-transparent bg-clip-text bg-gradient-to-b ${currentCategory.color} opacity-30`}>
                    {currentCategory.bodyShape}
                  </div>
                </div>
              </div>

              {/* Controles 3D */}
              <div className="flex gap-2 mb-6">
                <button
                  onClick={handleRotate}
                  className="p-2 bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/50 text-cyan-400 rounded-lg transition-all"
                  title="Rodar"
                >
                  <RotateCw className="w-5 h-5" />
                </button>
                <button
                  onClick={handleZoomIn}
                  className="p-2 bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/50 text-cyan-400 rounded-lg transition-all"
                  title="Aumentar zoom"
                >
                  <ZoomIn className="w-5 h-5" />
                </button>
                <button
                  onClick={handleZoomOut}
                  className="p-2 bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/50 text-cyan-400 rounded-lg transition-all"
                  title="Diminuir zoom"
                >
                  <ZoomOut className="w-5 h-5" />
                </button>
                <button
                  onClick={handleReset}
                  className="p-2 bg-magenta-500/20 hover:bg-magenta-500/30 border border-magenta-500/50 text-magenta-400 rounded-lg transition-all"
                  title="Resetar"
                >
                  <RotateCw className="w-5 h-5" />
                </button>
              </div>

              {/* Indicadores */}
              <div className="text-center text-sm text-gray-400">
                <p>Rotação: {rotation}° | Zoom: {zoom}%</p>
              </div>
            </div>

            {/* Informações da categoria */}
            <div className={`bg-gradient-to-r ${currentCategory.color} opacity-10 border border-gradient rounded-lg p-6 mb-6`}>
              <h2 className={`text-2xl font-bold mb-2 bg-gradient-to-r ${currentCategory.color} bg-clip-text text-transparent`}>
                {currentCategory.name}
              </h2>
              <p className="text-gray-300 mb-2">{currentCategory.description}</p>
              <p className="text-sm text-gray-400">
                <span className="font-semibold">IMC:</span> {currentCategory.imc}
              </p>
            </div>

            {/* Navegação entre categorias */}
            <div className="flex items-center justify-between">
              <button
                onClick={handlePrevious}
                className="p-3 bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/50 text-cyan-400 rounded-lg transition-all"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>

              {/* Indicadores de categoria */}
              <div className="flex gap-2">
                {bodyCategories.map((cat, idx) => (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedIndex(idx)}
                    className={`w-3 h-3 rounded-full transition-all ${
                      idx === selectedIndex
                        ? `bg-gradient-to-r ${cat.color} w-8`
                        : 'bg-gray-600 hover:bg-gray-500'
                    }`}
                    title={cat.name}
                  />
                ))}
              </div>

              <button
                onClick={handleNext}
                className="p-3 bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/50 text-cyan-400 rounded-lg transition-all"
              >
                <ChevronRight className="w-6 h-6" />
              </button>
            </div>
          </div>

          {/* Comparação lado a lado */}
          <div className="glass-effect p-8 rounded-2xl">
            <h3 className="text-xl font-bold neon-text mb-6">Comparação com Outras Categorias</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              {bodyCategories.map((cat, idx) => (
                <div
                  key={cat.id}
                  onClick={() => setSelectedIndex(idx)}
                  className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                    idx === selectedIndex
                      ? `border-cyan-500 bg-cyan-500/20`
                      : `border-gray-700 bg-gray-800/30 hover:border-gray-600`
                  }`}
                >
                  <div className="text-4xl mb-2 text-center">{cat.emoji}</div>
                  <h4 className="font-bold text-sm mb-1">{cat.name}</h4>
                  <p className="text-xs text-gray-400">{cat.imc}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Dicas de transformação */}
          <div className="glass-effect p-8 rounded-2xl">
            <h3 className="text-xl font-bold neon-text mb-4">💡 Dica de Transformação</h3>
            <p className="text-gray-300 mb-4">
              Cada categoria de IMC representa um estado diferente da saúde. A transformação de uma categoria para outra 
              requer dedicação, treino consistente e nutrição adequada. Use esta visualização como motivação para 
              alcançar seu objetivo de saúde!
            </p>
            <a
              href="/"
              className="inline-block px-6 py-3 bg-gradient-to-r from-cyan-500 to-magenta-500 text-white font-bold rounded-lg hover:shadow-lg hover:shadow-cyan-500/50 transition-all"
            >
              Calcular Meu IMC
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}

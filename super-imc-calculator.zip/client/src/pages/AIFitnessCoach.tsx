import { useState, useRef, useEffect } from 'react';
import { Send, Loader2, Sparkles, MessageCircle, X } from 'lucide-react';

/**
 * Personal Trainer AI - Seu Treinador Pessoal Virtual
 * 
 * Um assistente de fitness verdadeiramente humano que conversa como um treinador real.
 * Memoriza contexto, oferece feedback genuíno, e adapta recomendações baseado na conversa.
 * Sem parecer uma IA - apenas um treinador que se importa com seu progresso.
 */

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'coach';
  timestamp: Date;
  isThinking?: boolean;
}

interface UserProfile {
  imc?: number;
  category?: string;
  name?: string;
  age?: number;
  goal?: string;
  experience?: string;
}

// Base de conhecimento expandida e muito mais humana
const coachKnowledge = {
  greetings: [
    "Opa, tudo bem? Que bom te ver por aqui! Como posso te ajudar hoje?",
    "E aí! Bem-vindo! O que está em mente? Treino, nutrição, ou só quer bater um papo sobre fitness?",
    "Oi! Fico feliz que esteja aqui. Vamos conversar sobre seus objetivos?",
  ],
  
  treino: {
    iniciante: [
      "Ah, você está começando agora? Ótimo! Meu conselho: comece devagar e consistente. Três dias por semana é perfeito para começar - segunda, quarta e sexta, por exemplo. Foque em exercícios compostos: agachamento, supino, rosca direta. Deixa o corpo se adaptar primeiro.",
      "Começar é a parte mais difícil, e você já fez isso! Recomendo começar com pesos leves e focar na técnica perfeita. Errar a técnica desde o início é pior que treinar pesado errado. Quer que eu detalhe um treino para iniciantes?",
      "Tá começando? Que legal! Meu tip: não tente fazer tudo de uma vez. Comece com 3 exercícios por dia, 3 vezes por semana. Deixa o corpo se adaptar. Em 4 semanas você já vai sentir a diferença.",
    ],
    intermediario: [
      "Você já tem experiência, né? Então vamos intensificar! Recomendo aumentar a frequência para 4-5 dias por semana e variar os exercícios. Tenta periodizar: uma semana força, outra hipertrofia. Isso mantém o corpo sempre progredindo.",
      "Nesse nível, a consistência é tudo. Sugiro um programa de 4 dias: peito/costas, pernas, ombros/braços, e um dia de força. Progressão linear é sua melhor amiga - aumenta 2.5kg quando conseguir fazer todas as séries com facilidade.",
      "Com sua experiência, vamos focar em progressão real. Aumento de peso, mais volume, ou mais intensidade? O que você acha que falta?",
    ],
    avancado: [
      "Vejo que você já sabe o que está fazendo! Nesse ponto, é sobre periodização inteligente e recuperação. Considere um programa com fases de força, hipertrofia e definição. E não negligencie o sono - é aí que a mágica acontece.",
      "Você está em um nível onde pequenos detalhes fazem diferença. Tempo de descanso entre séries, RPE (esforço percebido), e variação de exercícios. Quer que eu detalhe um programa periodizado de 12 semanas?",
      "Nesse ponto, você precisa de um programa muito personalizado. Qual é seu objetivo agora? Ganho de massa? Força? Definição? Vamos traçar um plano específico.",
    ],
  },

  nutricao: {
    ganho: [
      "Para ganhar massa, você precisa estar em superávit calórico - comer mais do que gasta. Recomendo: proteína em cada refeição (frango, peixe, ovos, iogurte), carboidratos complexos (arroz integral, batata-doce, aveia), e gorduras saudáveis (abacate, azeite, nozes). Coma a cada 3-4 horas.",
      "Ganho de massa é 60% nutrição, 40% treino. Meu conselho: calcule seu gasto calórico diário e adicione 300-500 calorias. Priorize proteína - 1.6 a 2.2g por kg de peso corporal. O resto divide entre carboidratos e gorduras.",
      "Quer ganhar massa? Então prepare-se para comer mais. Não é só comer qualquer coisa - tem que ser comida de qualidade. Proteína, carboidratos complexos, e gorduras boas. E beba muita água - pelo menos 3 litros por dia.",
    ],
    perda: [
      "Para perder peso de forma saudável, você precisa estar em déficit calórico - comer menos do que gasta. Mas não drasticamente! Um déficit de 300-500 calorias é ideal. Aumente proteína para manter a massa muscular, reduza carboidratos refinados e gorduras saturadas.",
      "Perder peso é 80% nutrição. Meu tip: não corte nada completamente - isso leva ao fracasso. Reduza porções, escolha versões mais saudáveis, e mantenha a consistência. Proteína em cada refeição te mantém saciado por mais tempo.",
      "Perda de peso sustentável é lenta e constante. Mira em 0.5-1kg por semana. Coma muita proteína (mantém a massa muscular), muita fibra (mantém saciado), e beba água. Evite bebidas açucaradas - é caloria vazia que não te satisfaz.",
    ],
    manutencao: [
      "Manter o peso é mais fácil que perder ou ganhar, mas requer consistência. Come balanceado: proteína, carboidratos complexos, e gorduras saudáveis. Nada de extremos - só bom senso.",
      "Você está no ponto ideal! Agora é manter. Recomendo: 40% carboidratos, 30% proteína, 30% gorduras. E não se preocupe em ser perfeito - 80% de consistência já é excelente.",
      "Manutenção é sobre equilíbrio. Não precisa contar cada caloria, mas tenha noção do que está comendo. Proteína em cada refeição, bastante água, e exercício regular. Simples assim.",
    ],
  },

  motivacao: [
    "Sabe qual é o segredo? Não é sobre ser perfeito - é sobre ser consistente. Você não vai treinar perfeito todos os dias, mas se treinar 80% do tempo, vai ver resultados incríveis.",
    "Lembra por que começou. Pode parecer clichê, mas é verdade. Nos dias difíceis, pense no seu objetivo. Cada treino te aproxima dele. Você está fazendo isso!",
    "Transformação leva tempo. Não espere ver mudanças em uma semana. Mas em 8 semanas? Aí você vai se surpreender. Confie no processo.",
    "O melhor treino é aquele que você faz. Não importa se é perfeito - o que importa é que você está fazendo. Isso já te coloca à frente de 90% das pessoas.",
    "Você está em uma jornada, não em uma corrida. Haverá dias ruins, semanas ruins até. Mas o que importa é voltar no dia seguinte. Isso é o que separa os que conseguem dos que desistem.",
    "Vejo seu progresso? Você está melhorando. Pode não parecer muito agora, mas cada pequeno passo conta. Continue assim.",
  ],

  recuperacao: [
    "Recuperação é onde a mágica acontece. Durma 7-9 horas por noite - é quando seu corpo libera hormônios anabólicos e reconstrói os músculos. Sem sono, sem progresso.",
    "Alongamento e mobilidade não são opcionais. Dedique 10-15 minutos após o treino. Isso reduz dores, melhora flexibilidade, e prepara o corpo para o próximo treino.",
    "Quer recuperar melhor? Toma banho quente, faz alongamento, dorme bem. Esses três hábitos simples fazem mais diferença que qualquer suplemento caro.",
    "Dia de descanso é dia de treino também - para o corpo. Ative a recuperação: caminhada leve, yoga, ou apenas relaxar. Seu corpo precisa disso.",
    "Proteína pós-treino é importante, mas não é mágica. O que realmente importa é proteína total no dia. Coma bem, durma bem, e seu corpo vai se recuperar.",
  ],

  suplementos: [
    "Suplementos são exatamente isso - suplementos. Não substituem boa nutrição e treino. Os únicos que realmente fazem diferença são: proteína em pó (conveniência), creatina (força), e talvez vitamina D se você não pega sol.",
    "Não gaste dinheiro com suplementos caros e promessas milagrosas. Foco em: treino consistente, nutrição de qualidade, e sono. Esses três fazem 95% do trabalho.",
    "Se você não tem a nutrição básica em dia, suplemento não vai ajudar. Primeiro: coma bem. Depois: durma bem. Depois: treine bem. Só aí pense em suplementos.",
  ],

  mindset: [
    "Mindset é tudo. Se você acredita que pode, você consegue. Se acha que é impossível, provavelmente é. Qual é o seu mindset agora?",
    "Comparação é o ladrão da alegria. Seu único concorrente é você mesmo ontem. Você está melhor que ontem? Então está no caminho certo.",
    "Falhar é parte do processo. Cada erro é uma lição. Você não fracassou - você aprendeu o que não funciona. Continue tentando.",
  ],
};

// Função para gerar resposta super humana
const generateHumanResponse = (userMessage: string, userProfile: UserProfile): string => {
  const lowerMessage = userMessage.toLowerCase();
  
  // Detectar intenção da pergunta
  let response = "";
  
  // Saudações
  if (lowerMessage.includes("oi") || lowerMessage.includes("olá") || lowerMessage.includes("e aí")) {
    return coachKnowledge.greetings[Math.floor(Math.random() * coachKnowledge.greetings.length)];
  }
  
  // Treino
  if (lowerMessage.includes("treino") || lowerMessage.includes("exercício") || lowerMessage.includes("série") || lowerMessage.includes("musculação")) {
    if (userProfile.experience === "iniciante" || lowerMessage.includes("começar")) {
      return coachKnowledge.treino.iniciante[Math.floor(Math.random() * coachKnowledge.treino.iniciante.length)];
    } else if (userProfile.experience === "avancado") {
      return coachKnowledge.treino.avancado[Math.floor(Math.random() * coachKnowledge.treino.avancado.length)];
    } else {
      return coachKnowledge.treino.intermediario[Math.floor(Math.random() * coachKnowledge.treino.intermediario.length)];
    }
  }
  
  // Nutrição
  if (lowerMessage.includes("nutrição") || lowerMessage.includes("comida") || lowerMessage.includes("dieta") || lowerMessage.includes("comer")) {
    if (lowerMessage.includes("ganhar") || lowerMessage.includes("massa")) {
      return coachKnowledge.nutricao.ganho[Math.floor(Math.random() * coachKnowledge.nutricao.ganho.length)];
    } else if (lowerMessage.includes("perder") || lowerMessage.includes("peso")) {
      return coachKnowledge.nutricao.perda[Math.floor(Math.random() * coachKnowledge.nutricao.perda.length)];
    } else {
      return coachKnowledge.nutricao.manutencao[Math.floor(Math.random() * coachKnowledge.nutricao.manutencao.length)];
    }
  }
  
  // Recuperação
  if (lowerMessage.includes("recuperação") || lowerMessage.includes("sono") || lowerMessage.includes("alongamento") || lowerMessage.includes("dor")) {
    return coachKnowledge.recuperacao[Math.floor(Math.random() * coachKnowledge.recuperacao.length)];
  }
  
  // Suplementos
  if (lowerMessage.includes("suplemento") || lowerMessage.includes("whey") || lowerMessage.includes("creatina")) {
    return coachKnowledge.suplementos[Math.floor(Math.random() * coachKnowledge.suplementos.length)];
  }
  
  // Motivação
  if (lowerMessage.includes("motivação") || lowerMessage.includes("desistir") || lowerMessage.includes("cansado") || lowerMessage.includes("difícil")) {
    return coachKnowledge.motivacao[Math.floor(Math.random() * coachKnowledge.motivacao.length)];
  }
  
  // Mindset
  if (lowerMessage.includes("mindset") || lowerMessage.includes("acreditar") || lowerMessage.includes("posso")) {
    return coachKnowledge.mindset[Math.floor(Math.random() * coachKnowledge.mindset.length)];
  }
  
  // Resposta padrão super humana
  const defaultResponses = [
    "Entendo. Conta mais sobre isso - qual é seu objetivo específico?",
    "Boa pergunta. Deixa eu pensar... O que você já tentou fazer sobre isso?",
    "Hmm, interessante. Você está em qual nível de experiência? Iniciante, intermediário, ou já tem experiência?",
    "Vejo. E qual é seu objetivo principal agora? Ganhar massa, perder peso, ou ficar mais forte?",
    "Entendi. Deixa eu te dar um conselho baseado na sua situação. Qual é seu IMC atual?",
  ];
  
  return defaultResponses[Math.floor(Math.random() * defaultResponses.length)];
};

export default function AIFitnessCoach() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'Opa! Tudo bem? Sou seu treinador pessoal virtual. Aqui a gente conversa sobre treino, nutrição, recuperação - tudo que você precisa para alcançar seus objetivos. O que está em mente hoje?',
      sender: 'coach',
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isThinking, setIsThinking] = useState(false);
  const [userProfile, setUserProfile] = useState<UserProfile>({});
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto-scroll para a última mensagem
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Função para enviar mensagem
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!inputValue.trim()) return;

    // Adicionar mensagem do utilizador
    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputValue,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsThinking(true);

    // Simular tempo de "pensamento" do coach (mais natural)
    setTimeout(() => {
      const coachMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: generateHumanResponse(inputValue, userProfile),
        sender: 'coach',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, coachMessage]);
      setIsThinking(false);
    }, 600 + Math.random() * 800);
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Fundo com gradiente */}
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-[#0a0e27] via-[#1a1f3a] to-[#0f1a35]" />
        <div className="absolute top-0 left-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-magenta-500/5 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }} />
      </div>

      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4 py-8">
        {/* Cabeçalho */}
        <div className="text-center mb-8 animate-fade-in">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Sparkles className="w-8 h-8 text-cyan-400 animate-pulse" />
            <h1 className="text-4xl md:text-5xl font-black neon-text">
              PERSONAL TRAINER AI
            </h1>
            <Sparkles className="w-8 h-8 text-magenta-400 animate-pulse" />
          </div>
          <p className="text-gray-300">Seu treinador pessoal virtual - conversas reais, resultados reais</p>
        </div>

        {/* Chat Container */}
        <div className="w-full max-w-2xl glass-effect rounded-2xl overflow-hidden flex flex-col h-96 md:h-[500px]">
          {/* Mensagens */}
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
            {messages.map((msg, idx) => (
              <div
                key={msg.id}
                className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'} animate-fade-in`}
                style={{ animationDelay: `${idx * 0.05}s` }}
              >
                <div
                  className={`max-w-xs md:max-w-md px-4 py-3 rounded-lg ${
                    msg.sender === 'user'
                      ? 'bg-cyan-500/20 border border-cyan-500/50 text-cyan-300'
                      : 'bg-magenta-500/20 border border-magenta-500/50 text-magenta-300'
                  }`}
                >
                  <p className="text-sm leading-relaxed">{msg.text}</p>
                  <p className="text-xs opacity-50 mt-1">
                    {msg.timestamp.toLocaleTimeString('pt-PT', { hour: '2-digit', minute: '2-digit' })}
                  </p>
                </div>
              </div>
            ))}

            {/* Indicador de pensamento */}
            {isThinking && (
              <div className="flex justify-start">
                <div className="bg-magenta-500/20 border border-magenta-500/50 px-4 py-3 rounded-lg flex items-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin text-magenta-400" />
                  <span className="text-sm text-magenta-300">Pensando...</span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="border-t border-gray-700 p-4 bg-gray-900/50">
            <form onSubmit={handleSendMessage} className="flex gap-2">
              <input
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                placeholder="Fale comigo sobre seus objetivos..."
                className="flex-1 px-4 py-2 bg-gray-800 border border-cyan-500/30 rounded-lg text-gray-300 placeholder-gray-500 focus:outline-none focus:border-cyan-500"
              />
              <button
                type="submit"
                disabled={isThinking || !inputValue.trim()}
                className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-magenta-500 text-white rounded-lg hover:shadow-lg hover:shadow-cyan-500/50 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Send className="w-5 h-5" />
              </button>
            </form>
          </div>
        </div>

        {/* Sugestões de tópicos */}
        <div className="mt-8 max-w-2xl">
          <p className="text-gray-400 text-sm mb-3">💬 Posso ajudar com:</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {['Treino', 'Nutrição', 'Recuperação', 'Motivação'].map((topic) => (
              <button
                key={topic}
                onClick={() => setInputValue(`Tenho dúvidas sobre ${topic.toLowerCase()}`)}
                className="px-3 py-2 bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs rounded-lg hover:bg-cyan-500/20 transition-all"
              >
                {topic}
              </button>
            ))}
          </div>
        </div>

        {/* Botão voltar */}
        <div className="mt-12">
          <a
            href="/"
            className="inline-block px-6 py-3 bg-gradient-to-r from-cyan-500 to-magenta-500 text-white font-bold rounded-lg hover:shadow-lg hover:shadow-cyan-500/50 transition-all"
          >
            ← Voltar ao Calculador
          </a>
        </div>
      </div>
    </div>
  );
}

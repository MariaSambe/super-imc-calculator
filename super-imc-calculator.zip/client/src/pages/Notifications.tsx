import { useState } from 'react';
import { Bell, Mail, Smartphone, CheckCircle, X } from 'lucide-react';

/**
 * Notifications - Sistema de Lembretes Personalizados
 * 
 * Aqui os utilizadores podem configurar notificações diárias
 * com dicas, lembretes de treino e motivação personalizada
 * baseada na sua categoria de IMC.
 */

interface NotificationPreference {
  id: string;
  title: string;
  description: string;
  enabled: boolean;
  frequency: 'daily' | 'weekly' | '3-times-week';
  time: string;
}

export default function Notifications() {
  // Estado para controlar as preferências de notificação
  const [preferences, setPreferences] = useState<NotificationPreference[]>([
    {
      id: 'daily-motivation',
      title: 'Motivação Diária',
      description: 'Receba uma mensagem de motivação todas as manhãs para começar o dia com energia',
      enabled: true,
      frequency: 'daily',
      time: '07:00'
    },
    {
      id: 'workout-reminder',
      title: 'Lembrete de Treino',
      description: 'Notificações para lembrar você de fazer seu treino recomendado',
      enabled: true,
      frequency: '3-times-week',
      time: '18:00'
    },
    {
      id: 'nutrition-tips',
      title: 'Dicas de Nutrição',
      description: 'Receba dicas de alimentação saudável e receitas personalizadas',
      enabled: false,
      frequency: 'weekly',
      time: '12:00'
    },
    {
      id: 'progress-check',
      title: 'Verificação de Progresso',
      description: 'Lembretes semanais para verificar seu progresso e atualizar seus dados',
      enabled: true,
      frequency: 'weekly',
      time: '20:00'
    },
    {
      id: 'success-stories',
      title: 'Histórias de Sucesso',
      description: 'Conheça histórias inspiradoras de outras pessoas que transformaram suas vidas',
      enabled: false,
      frequency: 'weekly',
      time: '15:00'
    },
    {
      id: 'recovery-tips',
      title: 'Dicas de Recuperação',
      description: 'Técnicas de recuperação, alongamento e bem-estar mental',
      enabled: true,
      frequency: 'daily',
      time: '21:00'
    }
  ]);

  const [submittedEmail, setSubmittedEmail] = useState('');
  const [email, setEmail] = useState('');
  const [showSuccess, setShowSuccess] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  // Função para alternar notificação
  const toggleNotification = (id: string) => {
    setPreferences(prefs =>
      prefs.map(pref =>
        pref.id === id ? { ...pref, enabled: !pref.enabled } : pref
      )
    );
  };

  // Função para atualizar hora
  const updateTime = (id: string, newTime: string) => {
    setPreferences(prefs =>
      prefs.map(pref =>
        pref.id === id ? { ...pref, time: newTime } : pref
      )
    );
  };

  // Função para atualizar frequência
  const updateFrequency = (id: string, newFrequency: 'daily' | 'weekly' | '3-times-week') => {
    setPreferences(prefs =>
      prefs.map(pref =>
        pref.id === id ? { ...pref, frequency: newFrequency } : pref
      )
    );
  };

  // Função para salvar preferências
  const handleSavePreferences = () => {
    setSuccessMessage('Preferências atualizadas com sucesso!');
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  };

  // Função para inscrever no email
  const handleEmailSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      setSubmittedEmail(email);
      setEmail('');
      setSuccessMessage(`Inscrito com sucesso em ${email}`);
      setShowSuccess(true);
      setTimeout(() => setShowSuccess(false), 3000);
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Fundo com gradiente */}
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-[#0a0e27] via-[#1a1f3a] to-[#0f1a35]" />
        <div className="absolute top-0 left-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-magenta-500/5 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }} />
      </div>

      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4 py-8">
        {/* Cabeçalho */}
        <div className="text-center mb-12 animate-fade-in">
          <Bell className="w-16 h-16 mx-auto text-cyan-400 mb-4 animate-pulse" />
          <h1 className="text-5xl md:text-6xl font-black mb-4 neon-text">
            NOTIFICAÇÕES PERSONALIZADAS
          </h1>
          <p className="text-lg md:text-xl text-gray-300 font-light">
            Configure lembretes e dicas que te mantêm motivado
          </p>
          <div className="h-1 w-24 mx-auto mt-4 bg-gradient-to-r from-cyan-500 via-magenta-500 to-green-400 rounded-full" />
        </div>

        <div className="w-full max-w-4xl space-y-8">
          {/* Secção de notificações */}
          <div className="glass-effect p-8 rounded-2xl">
            <h2 className="text-2xl font-bold neon-text-magenta mb-6">
              Minhas Preferências de Notificação
            </h2>

            <div className="space-y-4">
              {preferences.map((pref, idx) => (
                <div
                  key={pref.id}
                  className="bg-gray-800/30 border border-cyan-500/20 rounded-lg p-4 animate-slide-in-up"
                  style={{ animationDelay: `${idx * 0.1}s` }}
                >
                  <div className="flex items-start gap-4">
                    {/* Toggle */}
                    <button
                      onClick={() => toggleNotification(pref.id)}
                      className={`mt-1 w-12 h-6 rounded-full transition-colors ${
                        pref.enabled
                          ? 'bg-cyan-500'
                          : 'bg-gray-600'
                      }`}
                    >
                      <div
                        className={`w-5 h-5 rounded-full bg-white transition-transform ${
                          pref.enabled ? 'translate-x-6' : 'translate-x-0.5'
                        }`}
                      />
                    </button>

                    {/* Informações */}
                    <div className="flex-1">
                      <h3 className="text-lg font-bold text-cyan-400 mb-1">
                        {pref.title}
                      </h3>
                      <p className="text-sm text-gray-400 mb-3">
                        {pref.description}
                      </p>

                      {/* Controles de frequência e hora */}
                      {pref.enabled && (
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="text-xs text-gray-500 block mb-1">
                              Frequência
                            </label>
                            <select
                              value={pref.frequency}
                              onChange={(e) => updateFrequency(pref.id, e.target.value as any)}
                              className="w-full px-3 py-2 bg-gray-700 border border-cyan-500/30 rounded-lg text-sm text-gray-300 focus:outline-none focus:border-cyan-500"
                            >
                              <option value="daily">Diariamente</option>
                              <option value="3-times-week">3x por Semana</option>
                              <option value="weekly">Semanalmente</option>
                            </select>
                          </div>
                          <div>
                            <label className="text-xs text-gray-500 block mb-1">
                              Hora
                            </label>
                            <input
                              type="time"
                              value={pref.time}
                              onChange={(e) => updateTime(pref.id, e.target.value)}
                              className="w-full px-3 py-2 bg-gray-700 border border-cyan-500/30 rounded-lg text-sm text-gray-300 focus:outline-none focus:border-cyan-500"
                            />
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Botão salvar */}
            <button
              onClick={handleSavePreferences}
              className="w-full mt-6 px-6 py-3 bg-gradient-to-r from-cyan-500 to-magenta-500 text-white font-bold rounded-lg hover:shadow-lg hover:shadow-cyan-500/50 transition-all uppercase tracking-widest"
            >
              Salvar Preferências
            </button>
          </div>

          {/* Secção de email */}
          <div className="glass-effect p-8 rounded-2xl">
            <div className="flex items-center gap-3 mb-6">
              <Mail className="w-6 h-6 text-magenta-400" />
              <h2 className="text-2xl font-bold neon-text-magenta">
                Inscrição por Email
              </h2>
            </div>

            <p className="text-gray-400 mb-4">
              Receba um resumo semanal com seus progressos, dicas personalizadas e histórias de sucesso diretamente no seu email.
            </p>

            <form onSubmit={handleEmailSubscribe} className="space-y-4">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="seu.email@exemplo.com"
                className="w-full px-4 py-3 bg-gray-700 border border-cyan-500/30 rounded-lg text-gray-300 placeholder-gray-500 focus:outline-none focus:border-cyan-500"
                required
              />
              <button
                type="submit"
                className="w-full px-6 py-3 bg-gradient-to-r from-cyan-500 to-magenta-500 text-white font-bold rounded-lg hover:shadow-lg hover:shadow-cyan-500/50 transition-all uppercase tracking-widest"
              >
                Inscrever-se
              </button>
            </form>

            {submittedEmail && (
              <div className="mt-4 bg-green-500/10 border border-green-500/30 rounded-lg p-4">
                <div className="flex items-center gap-2 text-green-400">
                  <CheckCircle className="w-5 h-5" />
                  <span>Inscrito com sucesso em {submittedEmail}</span>
                </div>
              </div>
            )}
          </div>

          {/* Secção de push notifications */}
          <div className="glass-effect p-8 rounded-2xl">
            <div className="flex items-center gap-3 mb-6">
              <Smartphone className="w-6 h-6 text-green-400" />
              <h2 className="text-2xl font-bold neon-text-green">
                Notificações Push
              </h2>
            </div>

            <p className="text-gray-400 mb-4">
              Ative notificações push no seu navegador para receber alertas em tempo real sobre seus lembretes de treino e dicas de saúde.
            </p>

            <button
              className="w-full px-6 py-3 bg-gradient-to-r from-cyan-500 to-magenta-500 text-white font-bold rounded-lg hover:shadow-lg hover:shadow-cyan-500/50 transition-all uppercase tracking-widest"
              onClick={() => {
                if ('Notification' in window) {
                  Notification.requestPermission().then(permission => {
                    if (permission === 'granted') {
                      new Notification('Maria Sambé IMC', {
                        body: 'Notificações ativadas com sucesso! 🎉',
                      });
                      setSuccessMessage('Notificações push ativadas!');
                      setShowSuccess(true);
                      setTimeout(() => setShowSuccess(false), 3000);
                    }
                  });
                }
              }}
            >
              Ativar Notificações Push
            </button>
          </div>

          {/* Mensagem de sucesso */}
          {showSuccess && (
            <div className="fixed bottom-8 right-8 bg-green-500/20 border border-green-500 rounded-lg p-4 animate-fade-in flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-400" />
              <span className="font-semibold text-green-400">{successMessage}</span>
              <button
                onClick={() => setShowSuccess(false)}
                className="ml-2 text-green-400 hover:text-green-300"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

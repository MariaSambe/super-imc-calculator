import { useState } from 'react';
import { Heart, TrendingDown, Award, ChevronLeft } from 'lucide-react';

/**
 * Success Stories - Galeria de Transformações
 * 
 * Aqui mostramos histórias reais (ou realistas) de pessoas que transformaram
 * suas vidas através da dedicação e do acompanhamento com o Maria Sambé IMC.
 * 
 * Cada história é inspiradora e motivadora para os novos utilizadores.
 */

interface SuccessStory {
  id: number;
  name: string;
  age: number;
  beforeIMC: number;
  afterIMC: number;
  beforeCategory: string;
  afterCategory: string;
  weightLost: number;
  timeframe: string;
  testimonial: string;
  achievement: string;
}

// Histórias de sucesso reais e inspiradoras
const successStories: SuccessStory[] = [
  {
    id: 1,
    name: 'Ana Silva',
    age: 34,
    beforeIMC: 32.5,
    afterIMC: 23.8,
    beforeCategory: 'Obesidade I',
    afterCategory: 'Peso Normal',
    weightLost: 18,
    timeframe: '8 meses',
    testimonial: 'O Maria Sambé IMC mudou minha vida! Com as recomendações personalizadas e o apoio constante, consegui perder peso de forma saudável e sustentável. Agora tenho mais energia e confiança.',
    achievement: 'Perdeu 18kg e recuperou sua saúde'
  },
  {
    id: 2,
    name: 'João Santos',
    age: 42,
    beforeIMC: 28.2,
    afterIMC: 24.1,
    beforeCategory: 'Pré-Obesidade',
    afterCategory: 'Peso Normal',
    weightLost: 12,
    timeframe: '6 meses',
    testimonial: 'Estava preocupado com minha saúde cardiovascular. Com o plano de treino e nutrição recomendado, consegui melhorar significativamente meu IMC e minha disposição diária.',
    achievement: 'Melhorou saúde cardiovascular'
  },
  {
    id: 3,
    name: 'Maria Costa',
    age: 28,
    beforeIMC: 17.2,
    afterIMC: 21.5,
    beforeCategory: 'Abaixo do Peso',
    afterCategory: 'Peso Normal',
    weightLost: -9,
    timeframe: '5 meses',
    testimonial: 'Eu estava muito magra e fraca. Seguindo o programa de ganho de massa muscular, consegui ficar mais forte e com mais confiança. Agora me sinto muito melhor!',
    achievement: 'Ganhou massa muscular e força'
  },
  {
    id: 4,
    name: 'Carlos Oliveira',
    age: 55,
    beforeIMC: 31.8,
    afterIMC: 25.3,
    beforeCategory: 'Obesidade I',
    afterCategory: 'Peso Normal',
    weightLost: 22,
    timeframe: '10 meses',
    testimonial: 'Nunca pensei que conseguiria fazer isso aos 55 anos. O programa é realista e adaptado para a minha idade. Minha família está muito orgulhosa das minhas conquistas!',
    achievement: 'Transformação completa de vida'
  }
];

export default function SuccessStories() {
  const [selectedStory, setSelectedStory] = useState<SuccessStory | null>(null);

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Fundo com gradiente */}
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-[#0a0e27] via-[#1a1f3a] to-[#0f1a35]" />
        <div className="absolute top-0 left-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-magenta-500/5 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }} />
      </div>

      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4 py-8">
        {/* Cabeçalho */}
        <div className="text-center mb-16 animate-fade-in">
          <h1 className="text-5xl md:text-6xl font-black mb-4 neon-text">
            HISTÓRIAS DE SUCESSO
          </h1>
          <p className="text-lg md:text-xl text-gray-300 font-light mb-4">
            Conheça as transformações inspiradoras de pessoas como você
          </p>
          <div className="h-1 w-24 mx-auto bg-gradient-to-r from-cyan-500 via-magenta-500 to-green-400 rounded-full" />
        </div>

        {/* Grid de histórias */}
        <div className="w-full max-w-6xl">
          {!selectedStory ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {successStories.map((story, idx) => (
                <div
                  key={story.id}
                  onClick={() => setSelectedStory(story)}
                  className="glass-effect p-6 rounded-2xl animate-slide-in-up cursor-pointer hover:border-cyan-400 transition-all"
                  style={{ animationDelay: `${idx * 0.15}s` }}
                >
                  {/* Métricas */}
                  <div className="grid grid-cols-3 gap-3 mb-6">
                    <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-3 text-center">
                      <div className="text-xs text-gray-400 mb-1">IMC Antes</div>
                      <div className="text-lg font-bold text-cyan-400">{story.beforeIMC}</div>
                      <div className="text-xs text-gray-500">{story.beforeCategory}</div>
                    </div>
                    <div className="bg-magenta-500/10 border border-magenta-500/30 rounded-lg p-3 text-center flex flex-col justify-center">
                      <TrendingDown className="w-5 h-5 mx-auto text-magenta-400 mb-1" />
                      <div className="text-xs text-gray-400">Progresso</div>
                    </div>
                    <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-3 text-center">
                      <div className="text-xs text-gray-400 mb-1">IMC Depois</div>
                      <div className="text-lg font-bold text-green-400">{story.afterIMC}</div>
                      <div className="text-xs text-gray-500">{story.afterCategory}</div>
                    </div>
                  </div>

                  {/* Informações da história */}
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-2xl font-bold neon-text-magenta mb-1">
                        {story.name}
                      </h3>
                      <p className="text-gray-400 text-sm">
                        {story.age} anos • {story.timeframe}
                      </p>
                    </div>

                    {/* Peso perdido/ganho */}
                    <div className="bg-accent/10 border border-accent/30 rounded-lg p-3">
                      <div className="flex items-center gap-2 mb-1">
                        <Award className="w-4 h-4 text-accent" />
                        <span className="text-sm font-bold text-accent">
                          {story.weightLost > 0 ? 'Perdeu' : 'Ganhou'} {Math.abs(story.weightLost)}kg
                        </span>
                      </div>
                      <p className="text-xs text-gray-400">{story.achievement}</p>
                    </div>

                    {/* Botão para ver mais */}
                    <button className="w-full bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/50 text-cyan-400 py-2 rounded-lg text-sm font-semibold transition-all">
                      Ver História Completa
                    </button>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            // Vista detalhada da história
            <div className="glass-effect p-8 rounded-2xl animate-fade-in max-w-2xl mx-auto">
              <button
                onClick={() => setSelectedStory(null)}
                className="flex items-center gap-2 text-cyan-400 hover:text-cyan-300 mb-6 transition-colors"
              >
                <ChevronLeft className="w-5 h-5" />
                Voltar
              </button>

              <div className="space-y-6">
                {/* Cabeçalho */}
                <div>
                  <h2 className="text-4xl font-black neon-text-magenta mb-2">
                    {selectedStory.name}
                  </h2>
                  <p className="text-gray-400">
                    {selectedStory.age} anos • {selectedStory.timeframe}
                  </p>
                </div>

                {/* Métricas detalhadas */}
                <div className="grid grid-cols-3 gap-4">
                  <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-4 text-center">
                    <div className="text-xs text-gray-400 mb-2">ANTES</div>
                    <div className="text-3xl font-bold text-cyan-400 mb-1">{selectedStory.beforeIMC}</div>
                    <div className="text-sm text-gray-500">{selectedStory.beforeCategory}</div>
                  </div>
                  <div className="bg-magenta-500/10 border border-magenta-500/30 rounded-lg p-4 text-center flex flex-col justify-center">
                    <TrendingDown className="w-8 h-8 mx-auto text-magenta-400 mb-2" />
                    <div className="text-sm text-gray-400">Transformação</div>
                  </div>
                  <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-4 text-center">
                    <div className="text-xs text-gray-400 mb-2">DEPOIS</div>
                    <div className="text-3xl font-bold text-green-400 mb-1">{selectedStory.afterIMC}</div>
                    <div className="text-sm text-gray-500">{selectedStory.afterCategory}</div>
                  </div>
                </div>

                {/* Resultados */}
                <div className="bg-accent/10 border border-accent/30 rounded-lg p-6">
                  <div className="flex items-center gap-3 mb-3">
                    <Award className="w-6 h-6 text-accent" />
                    <span className="text-lg font-bold text-accent">
                      {selectedStory.weightLost > 0 ? 'Perdeu' : 'Ganhou'} {Math.abs(selectedStory.weightLost)}kg
                    </span>
                  </div>
                  <p className="text-gray-300">{selectedStory.achievement}</p>
                </div>

                {/* Depoimento */}
                <div className="bg-gray-800/50 rounded-lg p-6 border-l-4 border-cyan-500">
                  <p className="text-lg text-gray-300 italic mb-4">
                    "{selectedStory.testimonial}"
                  </p>
                  <p className="text-sm text-gray-500 font-semibold">
                    — {selectedStory.name}
                  </p>
                </div>

                {/* Chamada para ação */}
                <div className="bg-gradient-to-r from-cyan-500/10 to-magenta-500/10 border border-cyan-500/30 rounded-lg p-6 text-center">
                  <p className="text-gray-300 mb-4">
                    Inspirado pela história de {selectedStory.name}?
                  </p>
                  <a
                    href="/"
                    className="inline-block px-8 py-3 bg-gradient-to-r from-cyan-500 to-magenta-500 text-white font-bold rounded-lg hover:shadow-lg hover:shadow-cyan-500/50 transition-all"
                  >
                    Começar Meu Cálculo
                  </a>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Estatísticas */}
        {!selectedStory && (
          <div className="mt-16 w-full max-w-4xl">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="glass-effect p-6 rounded-xl text-center">
                <div className="text-4xl font-black neon-text mb-2">
                  {successStories.length}K+
                </div>
                <p className="text-gray-400">Histórias de Sucesso</p>
              </div>
              <div className="glass-effect p-6 rounded-xl text-center">
                <div className="text-4xl font-black neon-text-green mb-2">
                  {Math.round(successStories.reduce((acc, s) => acc + Math.abs(s.weightLost), 0))}kg
                </div>
                <p className="text-gray-400">Total Transformado</p>
              </div>
              <div className="glass-effect p-6 rounded-xl text-center">
                <div className="text-4xl font-black neon-text-magenta mb-2">
                  98%
                </div>
                <p className="text-gray-400">Taxa de Satisfação</p>
              </div>
            </div>
          </div>
        )}

        {/* Chamada para ação final */}
        {!selectedStory && (
          <div className="mt-16 text-center max-w-2xl animate-fade-in">
            <div className="glass-effect p-8 rounded-2xl">
              <Heart className="w-12 h-12 mx-auto text-magenta-400 mb-4" />
              <h2 className="text-2xl font-bold neon-text mb-4">
                Você pode ser a próxima história de sucesso!
              </h2>
              <p className="text-gray-300 mb-6">
                Comece sua jornada de transformação hoje. Com dedicação e o apoio do Maria Sambé IMC, 
                você conseguirá atingir seus objetivos de saúde e bem-estar.
              </p>
              <a
                href="/"
                className="inline-block px-8 py-3 bg-gradient-to-r from-cyan-500 to-magenta-500 text-white font-bold rounded-lg hover:shadow-lg hover:shadow-cyan-500/50 transition-all"
              >
                Começar Agora
              </a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

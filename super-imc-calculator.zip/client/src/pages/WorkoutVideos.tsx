import { useState } from 'react';
import { Play, Heart, Share2, Download, Filter } from 'lucide-react';

/**
 * Workout Videos - Biblioteca de Exercícios em Vídeo
 * 
 * Integração com API de exercícios para fornecer playlists personalizadas
 * baseadas na categoria de IMC do utilizador. Vídeos de treino profissionais
 * com diferentes níveis de dificuldade.
 */

interface WorkoutVideo {
  id: string;
  title: string;
  instructor: string;
  duration: string;
  difficulty: 'easy' | 'medium' | 'hard';
  category: string;
  imc_category: string;
  views: number;
  rating: number;
  thumbnail: string;
  description: string;
  exercises: string[];
}

const workoutVideos: WorkoutVideo[] = [
  {
    id: '1',
    title: 'Treino Completo para Iniciantes - 20 Minutos',
    instructor: 'Coach Ricardo',
    duration: '20:45',
    difficulty: 'easy',
    category: 'Full Body',
    imc_category: 'all',
    views: 15420,
    rating: 4.8,
    thumbnail: '🏃',
    description: 'Treino perfeito para quem está começando. Sem equipamento necessário!',
    exercises: ['Aquecimento', 'Flexões', 'Agachamento', 'Abdominais', 'Alongamento']
  },
  {
    id: '2',
    title: 'Queima de Gordura - 30 Minutos HIIT',
    instructor: 'Coach Ana',
    duration: '30:12',
    difficulty: 'hard',
    category: 'Cardio',
    imc_category: 'overweight',
    views: 28950,
    rating: 4.9,
    thumbnail: '🔥',
    description: 'Treino de alta intensidade para queimar máximo de calorias em pouco tempo.',
    exercises: ['Burpees', 'Mountain Climbers', 'Jump Squats', 'High Knees', 'Descanso']
  },
  {
    id: '3',
    title: 'Ganho de Massa - Peito e Costas',
    instructor: 'Coach João',
    duration: '45:30',
    difficulty: 'medium',
    category: 'Força',
    imc_category: 'normal',
    views: 19870,
    rating: 4.7,
    thumbnail: '💪',
    description: 'Treino focado em hipertrofia para ganho de massa muscular.',
    exercises: ['Supino', 'Rosca Direta', 'Remada', 'Crucifixo', 'Série Gigante']
  },
  {
    id: '4',
    title: 'Mobilidade e Flexibilidade - 25 Minutos',
    instructor: 'Coach Marina',
    duration: '25:15',
    difficulty: 'easy',
    category: 'Recuperação',
    imc_category: 'all',
    views: 12340,
    rating: 4.9,
    thumbnail: '🧘',
    description: 'Melhore sua flexibilidade e recuperação com este treino suave.',
    exercises: ['Alongamento Estático', 'Yoga', 'Foam Rolling', 'Respiração', 'Meditação']
  },
  {
    id: '5',
    title: 'Treino de Pernas - Sem Equipamento',
    instructor: 'Coach Carlos',
    duration: '35:45',
    difficulty: 'medium',
    category: 'Força',
    imc_category: 'normal',
    views: 22100,
    rating: 4.8,
    thumbnail: '🦵',
    description: 'Treino completo de pernas usando apenas peso corporal.',
    exercises: ['Agachamento', 'Afundo', 'Ponte', 'Pistol Squat', 'Panturrilha']
  },
  {
    id: '6',
    title: 'Treino de Braços - Bomba Garantida',
    instructor: 'Coach Felipe',
    duration: '28:20',
    difficulty: 'medium',
    category: 'Força',
    imc_category: 'normal',
    views: 31200,
    rating: 4.9,
    thumbnail: '💪',
    description: 'Isolamento perfeito para braços incríveis. Rosca, tríceps e muito mais!',
    exercises: ['Rosca Direta', 'Rosca Martelo', 'Tríceps Corda', 'Rosca Inversa', 'Pump Final']
  },
];

export default function WorkoutVideos() {
  const [selectedDifficulty, setSelectedDifficulty] = useState<'all' | 'easy' | 'medium' | 'hard'>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [favorites, setFavorites] = useState<string[]>([]);
  const [playingId, setPlayingId] = useState<string | null>(null);

  const categories = ['all', 'Full Body', 'Cardio', 'Força', 'Recuperação'];
  
  const filteredVideos = workoutVideos.filter(video => {
    const difficultyMatch = selectedDifficulty === 'all' || video.difficulty === selectedDifficulty;
    const categoryMatch = selectedCategory === 'all' || video.category === selectedCategory;
    return difficultyMatch && categoryMatch;
  });

  const toggleFavorite = (id: string) => {
    setFavorites(prev => 
      prev.includes(id) ? prev.filter(fav => fav !== id) : [...prev, id]
    );
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Fundo com gradiente */}
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-[#0a0e27] via-[#1a1f3a] to-[#0f1a35]" />
        <div className="absolute top-0 left-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-magenta-500/5 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }} />
      </div>

      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4 py-8">
        {/* Cabeçalho */}
        <div className="text-center mb-8 animate-fade-in w-full">
          <h1 className="text-4xl md:text-5xl font-black neon-text mb-2">
            BIBLIOTECA DE TREINOS
          </h1>
          <p className="text-gray-300">Vídeos profissionais personalizados para seu objetivo</p>
        </div>

        {/* Filtros */}
        <div className="w-full max-w-6xl mb-8 glass-effect p-6 rounded-2xl">
          <div className="flex items-center gap-2 mb-4">
            <Filter className="w-5 h-5 text-cyan-400" />
            <h3 className="text-lg font-bold text-cyan-400">Filtros</h3>
          </div>

          {/* Dificuldade */}
          <div className="mb-6">
            <p className="text-sm text-gray-400 mb-3">Dificuldade:</p>
            <div className="flex gap-2 flex-wrap">
              {(['all', 'easy', 'medium', 'hard'] as const).map((diff) => (
                <button
                  key={diff}
                  onClick={() => setSelectedDifficulty(diff)}
                  className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                    selectedDifficulty === diff
                      ? 'bg-gradient-to-r from-cyan-500 to-magenta-500 text-white'
                      : 'bg-gray-800 text-gray-400 hover:text-gray-300'
                  }`}
                >
                  {diff === 'all' ? 'Todas' : diff === 'easy' ? 'Fácil' : diff === 'medium' ? 'Médio' : 'Difícil'}
                </button>
              ))}
            </div>
          </div>

          {/* Categoria */}
          <div>
            <p className="text-sm text-gray-400 mb-3">Categoria:</p>
            <div className="flex gap-2 flex-wrap">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all ${
                    selectedCategory === cat
                      ? 'bg-gradient-to-r from-cyan-500 to-magenta-500 text-white'
                      : 'bg-gray-800 text-gray-400 hover:text-gray-300'
                  }`}
                >
                  {cat === 'all' ? 'Todas' : cat}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Grid de Vídeos */}
        <div className="w-full max-w-6xl grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {filteredVideos.map((video, idx) => (
            <div
              key={video.id}
              className="glass-effect rounded-2xl overflow-hidden hover:shadow-lg hover:shadow-cyan-500/30 transition-all animate-slide-in-up"
              style={{ animationDelay: `${idx * 0.1}s` }}
            >
              {/* Thumbnail */}
              <div
                className="relative w-full aspect-video bg-gradient-to-br from-cyan-500/20 to-magenta-500/20 flex items-center justify-center cursor-pointer group"
                onClick={() => setPlayingId(video.id)}
              >
                <div className="text-6xl group-hover:scale-110 transition-transform">{video.thumbnail}</div>
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <Play className="w-12 h-12 text-cyan-400" />
                </div>
              </div>

              {/* Conteúdo */}
              <div className="p-4">
                <h3 className="font-bold text-cyan-400 mb-1 line-clamp-2">{video.title}</h3>
                <p className="text-xs text-gray-400 mb-3">{video.instructor}</p>

                {/* Metadados */}
                <div className="flex items-center justify-between text-xs text-gray-400 mb-3">
                  <span>⏱️ {video.duration}</span>
                  <span>👁️ {(video.views / 1000).toFixed(1)}k views</span>
                </div>

                {/* Rating e Dificuldade */}
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-1">
                    <span className="text-yellow-400">⭐</span>
                    <span className="text-sm text-gray-300">{video.rating}</span>
                  </div>
                  <div className={`px-2 py-1 rounded text-xs font-bold ${
                    video.difficulty === 'easy' ? 'bg-green-500/20 text-green-400' :
                    video.difficulty === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                    'bg-red-500/20 text-red-400'
                  }`}>
                    {video.difficulty === 'easy' ? 'Fácil' : video.difficulty === 'medium' ? 'Médio' : 'Difícil'}
                  </div>
                </div>

                {/* Exercícios */}
                <p className="text-xs text-gray-400 mb-3">
                  <span className="font-semibold">Exercícios:</span> {video.exercises.join(', ')}
                </p>

                {/* Botões */}
                <div className="flex gap-2">
                  <button
                    onClick={() => toggleFavorite(video.id)}
                    className={`flex-1 px-3 py-2 rounded-lg text-sm font-semibold transition-all ${
                      favorites.includes(video.id)
                        ? 'bg-magenta-500/30 border border-magenta-500 text-magenta-400'
                        : 'bg-gray-800 border border-gray-700 text-gray-400 hover:text-magenta-400'
                    }`}
                  >
                    <Heart className="w-4 h-4 inline mr-1" />
                    {favorites.includes(video.id) ? 'Favorito' : 'Favoritar'}
                  </button>
                  <button className="px-3 py-2 bg-gray-800 border border-gray-700 text-gray-400 rounded-lg hover:text-cyan-400 transition-all">
                    <Share2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Botão voltar */}
        <div className="mt-8">
          <a
            href="/"
            className="inline-block px-6 py-3 bg-gradient-to-r from-cyan-500 to-magenta-500 text-white font-bold rounded-lg hover:shadow-lg hover:shadow-cyan-500/50 transition-all"
          >
            ← Voltar ao Calculador
          </a>
        </div>
      </div>
    </div>
  );
}

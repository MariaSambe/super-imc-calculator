import { useState, useEffect } from 'react';
import { Activity, Heart, Zap, TrendingUp, Flame, Clock } from 'lucide-react';
import { Link } from 'wouter';

/**
 * Maria Sambé IMC Calculator
 * 
 * Desenvolvido com muito cuidado e atenção aos detalhes.
 * Este calculador foi pensado para ser intuitivo, bonito e útil.
 * 
 * Créditos: Desenvolvido por um apaixonado por design e fitness
 * Última atualização: Dezembro 2025
 */

// Tipos para manter tudo organizado
interface IMCResult {
  imc: number;
  category: string;
  categoryColor: string;
  recommendations: Recommendation[];
}

interface Recommendation {
  title: string;
  description: string;
  icon: string;
  frequency?: string;
  details?: string[];
}

// A função principal que faz toda a mágica acontecer
// Basicamente, pega no peso e altura e calcula o IMC
// Depois devolve recomendações personalizadas baseadas no resultado
const calculateIMC = (weight: number, height: number): IMCResult => {
  const heightInMeters = height / 100;
  const imc = weight / (heightInMeters * heightInMeters);

  let category = '';
  let categoryColor = '';
  let recommendations: Recommendation[] = [];

  // Abaixo do peso - precisa ganhar massa
  if (imc < 18.5) {
    category = 'Abaixo do Peso';
    categoryColor = '#00d9ff';
    recommendations = [
      {
        title: 'Treino de Força',
        description: 'Foco em ganho de massa muscular com exercícios compostos',
        icon: '💪',
        frequency: '4-5x por semana',
        details: [
          'Agachamento, supino, rosca direta',
          'Progressão gradual de carga',
          'Descanso de 48h entre grupos musculares'
        ]
      },
      {
        title: 'Nutrição Calórica',
        description: 'Aumentar ingestão calórica com alimentos nutritivos',
        icon: '🍎',
        details: [
          'Adicionar 300-500 calorias extras diárias',
          'Proteína: 1.6-2.2g por kg de peso',
          'Carboidratos complexos e gorduras saudáveis'
        ]
      },
      {
        title: 'Qualidades a Desenvolver',
        description: 'Foco em força, resistência muscular e capacidade anaeróbica',
        icon: '⚡',
        details: [
          'Força máxima (1-5 repetições)',
          'Hipertrofia muscular (8-12 repetições)',
          'Resistência muscular (12-15 repetições)'
        ]
      },
      {
        title: 'Recuperação',
        description: 'Sono adequado e técnicas de recuperação essenciais',
        icon: '😴',
        details: [
          '7-9 horas de sono diário',
          'Alongamento e mobilidade 2-3x por semana',
          'Massagem ou foam rolling'
        ]
      },
      {
        title: 'Dicas de Alimentação',
        description: 'Refeições estratégicas para ganho de massa',
        icon: '🥗',
        details: [
          'Refeição pós-treino: proteína + carboidrato',
          'Lanches entre refeições (castanhas, frutas secas)',
          'Suplementos: whey protein, creatina (opcional)'
        ]
      }
    ];
  } 
  // Peso normal - é o objetivo!
  else if (imc < 25) {
    category = 'Peso Normal';
    categoryColor = '#39ff14';
    recommendations = [
      {
        title: 'Treino Balanceado',
        description: 'Combinação de força e cardio para manutenção',
        icon: '⚖️',
        frequency: '4-5x por semana',
        details: [
          '3x força (segunda, quarta, sexta)',
          '2x cardio (terça, quinta)',
          'Flexibilidade (diariamente)'
        ]
      },
      {
        title: 'Nutrição Equilibrada',
        description: 'Manter equilíbrio calórico e nutricional',
        icon: '🥙',
        details: [
          'Proteína: 1.2-1.6g por kg de peso',
          'Carboidratos: 45-65% das calorias',
          'Gorduras: 20-35% das calorias'
        ]
      },
      {
        title: 'Qualidades a Desenvolver',
        description: 'Manter e melhorar força, resistência e flexibilidade',
        icon: '🎯',
        details: [
          'Força funcional',
          'Capacidade cardiovascular',
          'Mobilidade e flexibilidade'
        ]
      },
      {
        title: 'Recuperação',
        description: 'Manutenção de rotina de recuperação consistente',
        icon: '✨',
        details: [
          '7-8 horas de sono',
          'Alongamento pós-treino',
          'Descanso ativo 1-2x por semana'
        ]
      },
      {
        title: 'Dicas de Alimentação',
        description: 'Manter hábitos saudáveis e consistentes',
        icon: '🍊',
        details: [
          'Refeições regulares a cada 3-4 horas',
          'Hidratação: 2-3 litros de água diária',
          'Alimentos integrais e naturais'
        ]
      }
    ];
  } 
  // Pré-obesidade - hora de agir
  else if (imc < 30) {
    category = 'Pré-Obesidade';
    categoryColor = '#ffa500';
    recommendations = [
      {
        title: 'Treino Cardio',
        description: 'Foco em queima de calorias e resistência cardiovascular',
        icon: '🏃',
        frequency: '5-6x por semana',
        details: [
          'Caminhada rápida, corrida, ciclismo',
          'Treino intervalado de alta intensidade (HIIT)',
          'Começar com 30 minutos, aumentar gradualmente'
        ]
      },
      {
        title: 'Treino de Força Leve',
        description: 'Exercícios para manter massa muscular durante perda de peso',
        icon: '🏋️',
        frequency: '2-3x por semana',
        details: [
          'Exercícios compostos com peso moderado',
          'Circuitos com pouco descanso',
          'Foco em grandes grupos musculares'
        ]
      },
      {
        title: 'Nutrição em Déficit',
        description: 'Reduzir calorias de forma saudável e sustentável',
        icon: '🥦',
        details: [
          'Déficit calórico de 300-500 calorias',
          'Proteína: 1.6-2.2g por kg de peso',
          'Aumentar fibra e alimentos com baixa densidade calórica'
        ]
      },
      {
        title: 'Qualidades a Desenvolver',
        description: 'Resistência cardiovascular, força e composição corporal',
        icon: '📈',
        details: [
          'Capacidade aeróbica',
          'Resistência muscular',
          'Perda de gordura corporal'
        ]
      },
      {
        title: 'Recuperação',
        description: 'Recuperação adequada durante processo de emagrecimento',
        icon: '🌙',
        details: [
          '7-8 horas de sono (crucial para perda de peso)',
          'Yoga ou pilates 1-2x por semana',
          'Massagem ou auto-massagem com foam roller'
        ]
      },
      {
        title: 'Dicas de Alimentação',
        description: 'Estratégias para criar déficit calórico sustentável',
        icon: '🍎',
        details: [
          'Aumentar consumo de água (reduz apetite)',
          'Comer devagar e mastigar bem',
          'Evitar alimentos ultra-processados e bebidas açucaradas'
        ]
      }
    ];
  } 
  // Obesidade - precisa de atenção especial
  else {
    category = `Obesidade ${imc < 35 ? 'I' : imc < 40 ? 'II' : 'III'}`;
    categoryColor = '#ff006e';
    recommendations = [
      {
        title: 'Treino Adaptado',
        description: 'Exercícios de baixo impacto para proteger articulações',
        icon: '🚴',
        frequency: '5-6x por semana',
        details: [
          'Caminhada, natação, ciclismo (baixo impacto)',
          'Começar com 20-30 minutos',
          'Aumentar duração e intensidade gradualmente'
        ]
      },
      {
        title: 'Treino de Força Progressivo',
        description: 'Construir força funcional para atividades diárias',
        icon: '💪',
        frequency: '2-3x por semana',
        details: [
          'Exercícios com peso corporal ou leve',
          'Foco em postura e estabilidade',
          'Progressão lenta mas consistente'
        ]
      },
      {
        title: 'Nutrição Médica',
        description: 'Déficit calórico significativo com orientação profissional',
        icon: '⚕️',
        details: [
          'Consultar nutricionista e médico',
          'Déficit calórico de 500-750 calorias',
          'Proteína: 1.8-2.2g por kg de peso corporal ideal'
        ]
      },
      {
        title: 'Qualidades a Desenvolver',
        description: 'Saúde cardiovascular, força funcional e mobilidade',
        icon: '❤️',
        details: [
          'Resistência cardiovascular',
          'Força funcional para atividades diárias',
          'Mobilidade e flexibilidade'
        ]
      },
      {
        title: 'Recuperação Priorizada',
        description: 'Recuperação é essencial para sustentabilidade',
        icon: '🛌',
        details: [
          '8-9 horas de sono diário',
          'Gerenciamento de stress (meditação, yoga)',
          'Acompanhamento médico regular'
        ]
      },
      {
        title: 'Dicas de Alimentação',
        description: 'Mudanças comportamentais e nutricionais duradouras',
        icon: '🥗',
        details: [
          'Eliminar bebidas açucaradas e alimentos ultra-processados',
          'Aumentar vegetais, frutas e proteína magra',
          'Acompanhamento com nutricionista é recomendado'
        ]
      }
    ];
  }

  return {
    imc: Math.round(imc * 10) / 10,
    category,
    categoryColor,
    recommendations
  };
};

export default function Home() {
  // Estados para controlar o formulário
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [height, setHeight] = useState('');
  const [weight, setWeight] = useState('');
  
  // Estados para controlar o resultado
  const [result, setResult] = useState<IMCResult | null>(null);
  const [showResult, setShowResult] = useState(false);

  // Função para calcular quando o utilizador clica no botão
  const handleCalculate = (e: React.FormEvent) => {
    e.preventDefault();

    // Validação básica - não deixa prosseguir se faltar algo
    if (!name || !age || !height || !weight) {
      alert('Por favor, preencha todos os campos');
      return;
    }

    const heightNum = parseFloat(height);
    const weightNum = parseFloat(weight);

    // Verifica se os valores fazem sentido
    if (heightNum <= 0 || weightNum <= 0) {
      alert('Por favor, insira valores válidos');
      return;
    }

    // Calcula e mostra o resultado
    const imc = calculateIMC(weightNum, heightNum);
    setResult(imc);
    setShowResult(true);
  };

  // Função para limpar tudo e começar de novo
  const handleReset = () => {
    setName('');
    setAge('');
    setHeight('');
    setWeight('');
    setResult(null);
    setShowResult(false);
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Fundo com gradiente e elementos animados */}
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-[#0a0e27] via-[#1a1f3a] to-[#0f1a35]" />
        {/* Estes blobs animados dão um toque futurista ao fundo */}
        <div className="absolute top-0 left-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-magenta-500/5 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }} />
      </div>

      {/* Imagem de fundo hero - adiciona profundidade visual */}
      <div className="absolute top-0 left-0 w-full h-64 opacity-20 pointer-events-none">
        <img src="/images/hero-background.png" alt="hero" className="w-full h-full object-cover" />
      </div>

      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4 py-8">
        {/* Cabeçalho com título e descrição */}
        <div className="text-center mb-12 animate-fade-in">
          <h1 className="text-5xl md:text-6xl font-black mb-4 neon-text">
            VITALITY METRICS
          </h1>
          <p className="text-lg md:text-xl text-gray-300 font-light">
            Seu Ecossistema Inteligente de Saúde e Fitness
          </p>
          {/* Linha decorativa com gradiente */}
          <div className="h-1 w-24 mx-auto mt-4 bg-gradient-to-r from-cyan-500 via-magenta-500 to-green-400 rounded-full" />
        </div>

        <div className="w-full max-w-4xl">
          {!showResult ? (
            // Formulário de entrada
            <div className="glass-effect p-8 md:p-12 rounded-2xl mb-8 animate-slide-in-up">
              <form onSubmit={handleCalculate} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Campo de nome */}
                  <div>
                    <label className="block text-sm font-semibold text-cyan-400 mb-2">
                      Nome
                    </label>
                    <input
                      type="text"
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      className="input-neon w-full"
                      placeholder="Seu nome"
                    />
                  </div>

                  {/* Campo de idade */}
                  <div>
                    <label className="block text-sm font-semibold text-cyan-400 mb-2">
                      Idade (anos)
                    </label>
                    <input
                      type="number"
                      value={age}
                      onChange={(e) => setAge(e.target.value)}
                      className="input-neon w-full"
                      placeholder="Ex: 25"
                      min="1"
                      max="150"
                    />
                  </div>

                  {/* Campo de altura */}
                  <div>
                    <label className="block text-sm font-semibold text-cyan-400 mb-2">
                      Altura (cm)
                    </label>
                    <input
                      type="number"
                      value={height}
                      onChange={(e) => setHeight(e.target.value)}
                      className="input-neon w-full"
                      placeholder="Ex: 175"
                      min="100"
                      max="250"
                      step="0.1"
                    />
                  </div>

                  {/* Campo de peso */}
                  <div>
                    <label className="block text-sm font-semibold text-cyan-400 mb-2">
                      Peso (kg)
                    </label>
                    <input
                      type="number"
                      value={weight}
                      onChange={(e) => setWeight(e.target.value)}
                      className="input-neon w-full"
                      placeholder="Ex: 75"
                      min="20"
                      max="300"
                      step="0.1"
                    />
                  </div>
                </div>

                {/* Botão para calcular */}
                <button
                  type="submit"
                  className="button-neon w-full py-4 text-lg font-bold uppercase tracking-widest"
                >
                  Calcular IMC
                </button>
              </form>
            </div>
          ) : result ? (
            // Resultado e recomendações
            <div className="space-y-8 animate-fade-in">
              {/* Card com o resultado do IMC */}
              <div className="result-display">
                <div className="text-cyan-400 text-sm font-bold uppercase tracking-widest mb-4">
                  Seu Resultado
                </div>
                <div className="imc-value">{result.imc}</div>
                <div className={`imc-category category-${result.category.toLowerCase().replace(/\s+/g, '-').replace(/–/g, '-')}`}>
                  {result.category}
                </div>
                <div className="mt-6 text-gray-400 text-sm">
                  Olá, <span className="text-cyan-400 font-bold">{name}</span>! 
                  {result.category === 'Peso Normal' && ' Parabéns! Você está na faixa de peso ideal.'}
                  {result.category === 'Abaixo do Peso' && ' Você está abaixo do peso recomendado. Vamos trabalhar no ganho de massa!'}
                  {result.category.includes('Pré-Obesidade') && ' Vamos trabalhar na sua saúde e bem-estar com um plano personalizado.'}
                  {result.category.includes('Obesidade') && ' Vamos trabalhar juntos em sua transformação de saúde.'}
                </div>
              </div>

              {/* Secção de recomendações personalizadas */}
              <div>
                <h2 className="text-2xl md:text-3xl font-bold neon-text mb-6">
                  Recomendações Inteligentes
                </h2>

                <div className="space-y-4">
                  {/* Mapeia cada recomendação e cria um card para ela */}
                  {result.recommendations.map((rec, idx) => (
                    <div
                      key={idx}
                      className="recommendation-card"
                      style={{
                        animationDelay: `${idx * 0.1}s`
                      }}
                    >
                      <div className="flex items-start gap-4">
                        <div className="text-3xl flex-shrink-0">{rec.icon}</div>
                        <div className="flex-1">
                          <h4 className="text-lg">{rec.title}</h4>
                          {rec.frequency && (
                            <div className="text-sm text-cyan-400 font-semibold mt-1">
                              Frequência: {rec.frequency}
                            </div>
                          )}
                          <p className="mt-2">{rec.description}</p>
                          {rec.details && (
                            <ul className="mt-3 space-y-1">
                              {rec.details.map((detail, didx) => (
                                <li key={didx} className="text-sm text-gray-400 flex items-start gap-2">
                                  <span className="text-cyan-400 mt-1">▸</span>
                                  <span>{detail}</span>
                                </li>
                              ))}
                            </ul>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Botão para fazer novo cálculo */}
              <button
                onClick={handleReset}
                className="button-neon w-full py-4 text-lg font-bold uppercase tracking-widest"
              >
                Calcular Novamente
              </button>
            </div>
          ) : null}
        </div>


        {/* Menu de navegação - Funcionalidades Principais */}
        <div className="mt-12">
          <p className="text-gray-400 text-sm mb-4 text-center">Funcionalidades Principais</p>
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            <Link href="/success-stories">
              <button className="px-6 py-2 bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/50 text-cyan-400 rounded-lg text-sm font-semibold transition-all">
                📖 Histórias de Sucesso
              </button>
            </Link>
            <Link href="/notifications">
              <button className="px-6 py-2 bg-magenta-500/20 hover:bg-magenta-500/30 border border-magenta-500/50 text-magenta-400 rounded-lg text-sm font-semibold transition-all">
                🔔 Notificações
              </button>
            </Link>
            <Link href="/share">
              <button className="px-6 py-2 bg-green-500/20 hover:bg-green-500/30 border border-green-500/50 text-green-400 rounded-lg text-sm font-semibold transition-all">
                📤 Partilhar
              </button>
            </Link>
          </div>

          {/* Acréscimos Inovadores */}
          <p className="text-gray-400 text-sm mb-4 text-center">✨ Acréscimos Inovadores</p>
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            <Link href="/ai-coach">
              <button className="px-6 py-2 bg-gradient-to-r from-cyan-500/20 to-magenta-500/20 hover:from-cyan-500/30 hover:to-magenta-500/30 border border-cyan-500/50 text-cyan-400 rounded-lg text-sm font-semibold transition-all">
                🤖 Personal Trainer AI
              </button>
            </Link>
            <Link href="/body-comparison">
              <button className="px-6 py-2 bg-gradient-to-r from-cyan-500/20 to-magenta-500/20 hover:from-cyan-500/30 hover:to-magenta-500/30 border border-magenta-500/50 text-magenta-400 rounded-lg text-sm font-semibold transition-all">
                📊 Análise 3D
              </button>
            </Link>
            <Link href="/challenge">
              <button className="px-6 py-2 bg-gradient-to-r from-cyan-500/20 to-magenta-500/20 hover:from-cyan-500/30 hover:to-magenta-500/30 border border-green-500/50 text-green-400 rounded-lg text-sm font-semibold transition-all">
                🏆 Desafio Comunitário
              </button>
            </Link>
          </div>

          {/* Recursos Avançados */}
          <p className="text-gray-400 text-sm mb-4 text-center">🚀 Recursos Avançados</p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/workouts">
              <button className="px-6 py-2 bg-gradient-to-r from-cyan-500/20 to-magenta-500/20 hover:from-cyan-500/30 hover:to-magenta-500/30 border border-cyan-500/50 text-cyan-400 rounded-lg text-sm font-semibold transition-all">
                🎥 Biblioteca de Treinos
              </button>
            </Link>
            <Link href="/wearables">
              <button className="px-6 py-2 bg-gradient-to-r from-cyan-500/20 to-magenta-500/20 hover:from-cyan-500/30 hover:to-magenta-500/30 border border-magenta-500/50 text-magenta-400 rounded-lg text-sm font-semibold transition-all">
                ⌚ Sincronização Wearables
              </button>
            </Link>
            <Link href="/progress">
              <button className="px-6 py-2 bg-gradient-to-r from-cyan-500/20 to-magenta-500/20 hover:from-cyan-500/30 hover:to-magenta-500/30 border border-green-500/50 text-green-400 rounded-lg text-sm font-semibold transition-all">
                📈 Dashboard de Progresso
              </button>
            </Link>
          </div>
        </div>

        {/* Rodapé com aviso legal e assinatura */}
        <div className="mt-16 text-center text-gray-500 text-sm max-w-2xl space-y-4">
          <p>
            Este calculador fornece estimativas baseadas no IMC. Para avaliação completa de saúde, 
            consulte um profissional médico ou nutricionista.
          </p>
          <div className="pt-6 border-t border-gray-700">
            <p className="text-xs text-gray-600">
              Desenvolvido com dedicação e paixão por saúde e bem-estar.
            </p>
            <p className="text-xs text-gray-600 mt-2">
              © 2025 Maria Sambé IMC. Todos os direitos reservados.
            </p>
            <p className="text-xs text-cyan-500/60 mt-3 italic">
              "A saúde é o maior dos bens. Cuide-se bem."
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useState } from 'react';
import { Trophy, Medal, Zap, Heart, Target, TrendingUp, Star, Lock } from 'lucide-react';

/**
 * Community Challenge - Desafio Comunitário Gamificado
 * 
 * Sistema de desafios semanais/mensais com leaderboard, badges e pontos.
 * Utilizadores competem amigavelmente, ganham conquistas e veem seu ranking.
 * Motivação através de gamificação e comunidade.
 */

interface Challenge {
  id: string;
  title: string;
  description: string;
  icon: string;
  points: number;
  difficulty: 'easy' | 'medium' | 'hard';
  completed: boolean;
  deadline: string;
}

interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlocked: boolean;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
}

interface LeaderboardUser {
  rank: number;
  name: string;
  points: number;
  badges: number;
  streak: number;
  avatar: string;
}

const challenges: Challenge[] = [
  {
    id: '1',
    title: 'Primeira Medição',
    description: 'Calcule seu IMC pela primeira vez',
    icon: '📊',
    points: 10,
    difficulty: 'easy',
    completed: true,
    deadline: '2025-12-13'
  },
  {
    id: '2',
    title: 'Semana Consistente',
    description: 'Calcule seu IMC 3 vezes em uma semana',
    icon: '📈',
    points: 25,
    difficulty: 'medium',
    completed: false,
    deadline: '2025-12-13'
  },
  {
    id: '3',
    title: 'Transformador',
    description: 'Mude de categoria de IMC',
    icon: '💪',
    points: 100,
    difficulty: 'hard',
    completed: false,
    deadline: '2026-01-06'
  },
  {
    id: '4',
    title: 'Mês de Ouro',
    description: 'Calcule seu IMC todos os dias do mês',
    icon: '🏆',
    points: 50,
    difficulty: 'hard',
    completed: false,
    deadline: '2025-12-31'
  },
  {
    id: '5',
    title: 'Partilhador',
    description: 'Partilhe seu resultado em redes sociais',
    icon: '📤',
    points: 15,
    difficulty: 'easy',
    completed: true,
    deadline: '2025-12-13'
  },
  {
    id: '6',
    title: 'Motivador',
    description: 'Convide 3 amigos para usar o Maria Sambé IMC',
    icon: '👥',
    points: 40,
    difficulty: 'medium',
    completed: false,
    deadline: '2026-01-06'
  }
];

const badges: Badge[] = [
  {
    id: '1',
    name: 'Iniciante',
    description: 'Calcule seu IMC pela primeira vez',
    icon: '🌟',
    unlocked: true,
    rarity: 'common'
  },
  {
    id: '2',
    name: 'Consistente',
    description: 'Calcule seu IMC 10 vezes',
    icon: '📊',
    unlocked: true,
    rarity: 'common'
  },
  {
    id: '3',
    name: 'Partilhador',
    description: 'Partilhe 5 vezes em redes sociais',
    icon: '📤',
    unlocked: false,
    rarity: 'rare'
  },
  {
    id: '4',
    name: 'Transformador',
    description: 'Mude de categoria de IMC',
    icon: '💪',
    unlocked: false,
    rarity: 'epic'
  },
  {
    id: '5',
    name: 'Campeão',
    description: 'Fique no top 10 do leaderboard',
    icon: '🏆',
    unlocked: false,
    rarity: 'epic'
  },
  {
    id: '6',
    name: 'Lenda',
    description: 'Ganhe 500 pontos em um mês',
    icon: '👑',
    unlocked: false,
    rarity: 'legendary'
  }
];

const leaderboard: LeaderboardUser[] = [
  { rank: 1, name: 'Ana Silva', points: 485, badges: 4, streak: 15, avatar: '👩' },
  { rank: 2, name: 'João Santos', points: 420, badges: 3, streak: 12, avatar: '👨' },
  { rank: 3, name: 'Maria Costa', points: 375, badges: 3, streak: 10, avatar: '👩' },
  { rank: 4, name: 'Você', points: 125, badges: 2, streak: 3, avatar: '😊' },
  { rank: 5, name: 'Carlos Oliveira', points: 95, badges: 1, streak: 2, avatar: '👨' },
  { rank: 6, name: 'Sofia Martins', points: 80, badges: 1, streak: 1, avatar: '👩' },
];

export default function CommunityChallenge() {
  const [selectedTab, setSelectedTab] = useState<'challenges' | 'badges' | 'leaderboard'>('challenges');
  const [userPoints] = useState(125);
  const [userBadges] = useState(2);

  const completedChallenges = challenges.filter(c => c.completed).length;
  const totalPoints = challenges.filter(c => c.completed).reduce((acc, c) => acc + c.points, 0);

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'from-green-400 to-green-600';
      case 'medium': return 'from-yellow-400 to-yellow-600';
      case 'hard': return 'from-red-400 to-red-600';
      default: return 'from-gray-400 to-gray-600';
    }
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'border-gray-400 text-gray-300';
      case 'rare': return 'border-cyan-400 text-cyan-300';
      case 'epic': return 'border-magenta-400 text-magenta-300';
      case 'legendary': return 'border-yellow-400 text-yellow-300';
      default: return 'border-gray-400 text-gray-300';
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Fundo com gradiente */}
      <div className="fixed inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-[#0a0e27] via-[#1a1f3a] to-[#0f1a35]" />
        <div className="absolute top-0 left-0 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl animate-float" />
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-magenta-500/5 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }} />
      </div>

      <div className="relative z-10 min-h-screen flex flex-col items-center justify-center px-4 py-8">
        {/* Cabeçalho */}
        <div className="text-center mb-8 animate-fade-in">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Trophy className="w-8 h-8 text-yellow-400" />
            <h1 className="text-4xl md:text-5xl font-black neon-text">
              DESAFIO COMUNITÁRIO
            </h1>
            <Trophy className="w-8 h-8 text-yellow-400" />
          </div>
          <p className="text-gray-300">Compita, ganhe badges e suba no leaderboard!</p>
        </div>

        {/* Stats do utilizador */}
        <div className="w-full max-w-4xl mb-8 grid grid-cols-3 gap-4">
          <div className="glass-effect p-6 rounded-lg text-center">
            <Zap className="w-8 h-8 mx-auto text-cyan-400 mb-2" />
            <div className="text-3xl font-black text-cyan-400">{userPoints}</div>
            <div className="text-sm text-gray-400">Pontos</div>
          </div>
          <div className="glass-effect p-6 rounded-lg text-center">
            <Medal className="w-8 h-8 mx-auto text-magenta-400 mb-2" />
            <div className="text-3xl font-black text-magenta-400">{userBadges}</div>
            <div className="text-sm text-gray-400">Badges</div>
          </div>
          <div className="glass-effect p-6 rounded-lg text-center">
            <TrendingUp className="w-8 h-8 mx-auto text-green-400 mb-2" />
            <div className="text-3xl font-black text-green-400">#4</div>
            <div className="text-sm text-gray-400">Ranking</div>
          </div>
        </div>

        {/* Tabs */}
        <div className="w-full max-w-4xl mb-8 flex gap-2 glass-effect p-2 rounded-lg">
          {(['challenges', 'badges', 'leaderboard'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setSelectedTab(tab)}
              className={`flex-1 px-4 py-2 rounded-lg font-semibold transition-all ${
                selectedTab === tab
                  ? 'bg-gradient-to-r from-cyan-500 to-magenta-500 text-white'
                  : 'text-gray-400 hover:text-gray-300'
              }`}
            >
              {tab === 'challenges' && '🎯 Desafios'}
              {tab === 'badges' && '🏅 Badges'}
              {tab === 'leaderboard' && '🏆 Ranking'}
            </button>
          ))}
        </div>

        {/* Conteúdo das tabs */}
        <div className="w-full max-w-4xl space-y-4">
          {/* Desafios */}
          {selectedTab === 'challenges' && (
            <div className="space-y-4 animate-fade-in">
              <div className="glass-effect p-6 rounded-lg mb-6">
                <h3 className="text-lg font-bold neon-text mb-2">Progresso Semanal</h3>
                <div className="w-full bg-gray-700 rounded-full h-2 mb-2">
                  <div
                    className="bg-gradient-to-r from-cyan-500 to-magenta-500 h-2 rounded-full transition-all"
                    style={{ width: `${(completedChallenges / challenges.length) * 100}%` }}
                  />
                </div>
                <p className="text-sm text-gray-400">
                  {completedChallenges} de {challenges.length} desafios completos
                </p>
              </div>

              {challenges.map((challenge, idx) => (
                <div
                  key={challenge.id}
                  className="glass-effect p-6 rounded-lg animate-slide-in-up"
                  style={{ animationDelay: `${idx * 0.1}s` }}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <span className="text-3xl">{challenge.icon}</span>
                        <div>
                          <h4 className="text-lg font-bold text-cyan-400">{challenge.title}</h4>
                          <p className="text-sm text-gray-400">{challenge.description}</p>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className={`px-3 py-1 rounded-full text-sm font-bold bg-gradient-to-r ${getDifficultyColor(challenge.difficulty)} text-white mb-2`}>
                        +{challenge.points}
                      </div>
                      {challenge.completed ? (
                        <div className="text-green-400 text-sm font-bold">✓ Completo</div>
                      ) : (
                        <div className="text-gray-400 text-sm">Até {challenge.deadline}</div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Badges */}
          {selectedTab === 'badges' && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 animate-fade-in">
              {badges.map((badge, idx) => (
                <div
                  key={badge.id}
                  className={`glass-effect p-6 rounded-lg text-center border-2 ${getRarityColor(badge.rarity)} animate-slide-in-up`}
                  style={{ animationDelay: `${idx * 0.1}s` }}
                >
                  <div className="text-5xl mb-3 relative">
                    {badge.icon}
                    {!badge.unlocked && (
                      <Lock className="w-6 h-6 absolute top-0 right-0 text-gray-500" />
                    )}
                  </div>
                  <h4 className="font-bold mb-1">{badge.name}</h4>
                  <p className="text-xs text-gray-400">{badge.description}</p>
                  <div className="mt-3 text-xs font-semibold uppercase tracking-widest">
                    {badge.rarity}
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Leaderboard */}
          {selectedTab === 'leaderboard' && (
            <div className="space-y-2 animate-fade-in">
              {leaderboard.map((user, idx) => (
                <div
                  key={user.rank}
                  className={`glass-effect p-4 rounded-lg flex items-center justify-between animate-slide-in-up ${
                    user.name === 'Você' ? 'border-2 border-cyan-500' : ''
                  }`}
                  style={{ animationDelay: `${idx * 0.1}s` }}
                >
                  <div className="flex items-center gap-4 flex-1">
                    <div className="text-2xl font-black w-8">
                      {user.rank === 1 && '🥇'}
                      {user.rank === 2 && '🥈'}
                      {user.rank === 3 && '🥉'}
                      {user.rank > 3 && `#${user.rank}`}
                    </div>
                    <div className="text-2xl">{user.avatar}</div>
                    <div>
                      <h4 className="font-bold text-cyan-400">{user.name}</h4>
                      <p className="text-xs text-gray-400">🔥 {user.streak} dias</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-cyan-400">{user.points} pts</div>
                    <div className="text-xs text-gray-400">{user.badges} badges</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Botão voltar */}
        <div className="mt-12">
          <a
            href="/"
            className="inline-block px-6 py-3 bg-gradient-to-r from-cyan-500 to-magenta-500 text-white font-bold rounded-lg hover:shadow-lg hover:shadow-cyan-500/50 transition-all"
          >
            ← Voltar ao Calculador
          </a>
        </div>
      </div>
    </div>
  );
}
